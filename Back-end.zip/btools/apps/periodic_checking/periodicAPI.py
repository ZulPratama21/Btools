from flask import Blueprint, jsonify, request
from flask import jsonify
from btools import limiter, role_required
from btools.apps.periodic_checking.periodicQuery import *

mod = Blueprint('periodic', __name__, url_prefix='/periodic')

"""
Menu : Periodic Checking Link Backup
"""
@mod.route('/linkbackup', methods=['GET'])
@role_required(['Master', 'NOC'])
def periodic_linkbackup():
    connection = create_connection()
    all_data = selectAllLinkBackup(connection)
    max_time = selectMaxTimeLinkBackup(connection)

    respon = jsonify(
        {
            "code": 200,
            "status": "OK",
            "data": {
                "all_periodic": all_data,
                "lastUpdate": max_time
            },
            "page": {
                "size": len(all_data),
                "total": 100,
                "totalPages": 5,
                "current": 1
            }
        }
    ), 200
    return respon

"""
Menu : Periodic Checking Link Main
"""
@mod.route('/linkmain', methods=['GET'])
@role_required(['Master', 'NOC'])
def periodic_linkmain():
    connection = create_connection()
    all_data = selectAllLinkMain(connection)
    max_time = selectMaxTimeLinkMain(connection)
    respon = jsonify(
        {
            "code": 200,
            "status": "OK",
            "data": {
                "all_periodic": all_data,
                "lastUpdate" : max_time
            },
            "page": {
                "size": len(all_data),
                "total": 100,
                "totalPages": 5,
                "current": 1
            }
        }
    ), 200
    return respon