from btools import mysql as MYSQL
import pymysql


def create_connection():
    connection = None
    try:
        connection = MYSQL.connect()
    except Exception as e:
        print(e)
    return connection


def selectMaxTimeLinkBackup(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(""" 
    SELECT MAX(DATE_FORMAT(time, '%d %b %Y')) AS time
    FROM automation_periodic_checking_link_backup;
    """)
    rows = cursor.fetchone()

    return rows


def selectMaxTimeLinkMain(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(""" 
    SELECT MAX(DATE_FORMAT(time, '%d %b %Y')) AS time
    FROM automation_periodic_checking_link_main;
    """)
    rows = cursor.fetchone()

    return rows


"""
Entity : automation_periodic_checking_link_backup
"""


def selectAllLinkBackup(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(""" 
        SELECT source, destination,ping, ROUND(AVG(receive), 2) as receive, ROUND(AVG(transmit), 2) as transmit, DATE_FORMAT(time, '%d %b %Y') as time,
        CASE
            WHEN MAX(CASE WHEN DATE(time) = CURDATE() THEN transmit END) > MAX(CASE WHEN DATE(time) = CURDATE() - INTERVAL 1 DAY THEN transmit END)  THEN 'Naik'
            WHEN MAX(CASE WHEN DATE(time) = CURDATE() THEN transmit END) < MAX(CASE WHEN DATE(time) = CURDATE() - INTERVAL 1 DAY THEN transmit END) THEN 'Turun'
            ELSE 'Stabil'
        END AS trend,
        CONCAT(
            IFNULL(
            CONCAT(
                ROUND(
                (
                    (
                    MAX(CASE WHEN DATE(time) = CURDATE() THEN transmit END) - MAX(CASE WHEN DATE(time) = CURDATE() - INTERVAL 1 DAY THEN transmit END)
                    ) / MAX(CASE WHEN DATE(time) = CURDATE() - INTERVAL 1 DAY THEN transmit END)
                ) * 100,
                2
                ),
                '%'
            ),
            '0.0%'
            )
        ) AS persentase_perubahan_transmit
        FROM automation_periodic_checking_link_backup
        WHERE 
        automation_periodic_checking_link_backup.time >= DATE_SUB(DATE(NOW()), INTERVAL 7 DAY) 
        GROUP BY destination
        ORDER BY transmit ASC
    """)
    rows = cursor.fetchall()

    return rows


"""
Entity : automation_periodic_checking_link_main
"""


def selectAllLinkMain(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute("""
    SELECT source, destination,ping, ROUND(AVG(receive), 2) as receive, ROUND(AVG(transmit), 2) as transmit, DATE_FORMAT(time, '%d %b %Y') as time,
    CASE
        WHEN MAX(CASE WHEN DATE(time) = CURDATE() THEN transmit END) > MAX(CASE WHEN DATE(time) = CURDATE() - INTERVAL 1 DAY THEN transmit END)  THEN 'Naik'
        WHEN MAX(CASE WHEN DATE(time) = CURDATE() THEN transmit END) < MAX(CASE WHEN DATE(time) = CURDATE() - INTERVAL 1 DAY THEN transmit END) THEN 'Turun'
        ELSE 'Stabil'
    END AS trend,
    CONCAT(
        IFNULL(
        CONCAT(
            ROUND(
            (
                (
                MAX(CASE WHEN DATE(time) = CURDATE() THEN transmit END) - MAX(CASE WHEN DATE(time) = CURDATE() - INTERVAL 1 DAY THEN transmit END)
                ) / MAX(CASE WHEN DATE(time) = CURDATE() - INTERVAL 1 DAY THEN transmit END)
            ) * 100,
            2
            ),
            '%'
        ),
        '0.0%'
        )
    ) AS persentase_perubahan_transmit
    FROM automation_periodic_checking_link_main
    WHERE 
    automation_periodic_checking_link_main.time >= DATE_SUB(DATE(NOW()), INTERVAL 7 DAY) 
    GROUP BY destination
    ORDER BY transmit ASC
    """)
    rows = cursor.fetchall()

    return rows
