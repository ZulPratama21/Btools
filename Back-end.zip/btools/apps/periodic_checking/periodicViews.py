from flask import Blueprint, render_template
from btools import role_required

mod = Blueprint('periodic', __name__, url_prefix='/periodic')

@mod.route('/linkbackup', methods=['GET'])
@role_required(['Master', 'NOC'])
def index_linkbackup():
    return render_template("periodic_checking/link_backup.html")

@mod.route('/linkmain', methods=['GET'])
@role_required(['Master', 'NOC'])
def index_linkmain():
    return render_template("periodic_checking/link_main.html")