from btools.apps.troubleshoot.troubleshootQuery import *
from btools.apps.troubleshoot import constants as CONSTANTS
from btools import limiter
from flask import Blueprint, jsonify, request, abort
from datetime import datetime
from puresnmp import get as SNMP_GET
import re
import requests
import routeros_api
import json
from btools import role_required


mod = Blueprint('troubeleshoot', __name__, url_prefix='/troubleshoot')


@mod.route('/bhome', methods=['GET', 'POST'])
@limiter.limit("30/minute")
def middleware_bhome():
    connection = create_connection()
    get_keyword = request.args.get('id_customer', type=str, default=None)
    get_action = request.args.get('action', type=str, default=None)

    if get_action == "update":
        list_router = selectAuthenticationJoinTroubleshootParent(connection)
        countClient = 0
        list_secret = []

        for parrent in list_router:
            parent_id = parrent['ID_Parent']
            parent_ip_address = parrent['IP_Address']
            parent_port_ssh = parrent['Port_API']
            parent_username = parrent['Username']
            parent_password = parrent['Password']
            parent_category = parrent['Category']

            if parent_category == 'bhome':
                try:
                    connection_parent = routeros_api.RouterOsApiPool(
                        parent_ip_address, parent_username, parent_password, plaintext_login=True)
                    api = connection_parent.get_api()

                    secret = api.get_resource('ppp/secret/')
                    secret_all = secret.get()

                    for x in range(len(secret_all)):
                        try:
                            secret_comment = secret_all[x]['comment']
                            secret_id_ca = re.findall(
                                'CA\d\w+', secret_comment)[0]
                            secret_name = secret_all[x]['name']
                            secret_profile = secret_all[x]['profile']
                            secret_remote_address = secret_all[x]['remote-address']
                            secret_noc_id = re.findall(
                                '[\d]\w+', secret_name)[0]

                            insertBhome(connection=connection, id_customer=secret_id_ca, name=secret_comment, id_noc=secret_noc_id, secret_user=secret_name,
                                        limitation=secret_profile, ip_address=secret_remote_address, id_parent=parent_id, id_olt=secret_noc_id[0])
                            list_secret.append(
                                {
                                    "ID_Customer": secret_id_ca,
                                    "Comment":  secret_comment,
                                    "ID_NOC": secret_noc_id
                                }
                            )
                        except:
                            continue
                except:
                    pass

        if not list_secret:
            message = "Tidak ada data terbaru yang tersedia."
        else:
            message = "Data berhasil diperbarui."

        respon = jsonify(
            {
                "code": 200,
                "status": "success",
                "data": list_secret,
                "message": message
            }
        ), 200
        return respon
    elif get_action == 'delete':
        deleteAllBhome(connection)
        respon = jsonify(
            {
                "code": 200,
                "status": "OK",
                "message": "DELETE ALL BHOME",
            }
        ), 200
        return respon

    if get_keyword:
        data = selectBhome(connection, get_keyword)
        respon = jsonify(
            {
                "code": 200,
                "status": "OK",
                "data": data
            }
        ), 200
        return respon

    all_data = selectAllBhome(connection)
    respon = jsonify(
        {
            "code": 200,
            "status": "OK",
            "data": all_data,
            "page": {
                "size": len(all_data),
                "total": 100,
                "totalPages": 5,
                "current": 1
            }
        }
    ), 200
    return respon


@mod.route('/realtime/queue/bhome', methods=['GET', 'POST'])
@role_required(['Master', 'NOC', 'CR'])
@limiter.limit("30/minute")
def realtime_queue_bhome():
    get_id_customer = request.args.get('id_customer', type=str, default=None)

    if get_id_customer == "null":
        abort(403)

    connection = create_connection()
    data = selectTroubleshhotBhomeJoinTroubleshootParent(
        connection, get_id_customer)

    if data == None:
        abort(403)

    pppoe_name = data['Secret_User']
    ip_parent = data['ip_parent']
    username_parent = data['username_parent']
    password_parent = data['password_parent']

    if pppoe_name != None:
        try:
            connection = routeros_api.RouterOsApiPool(
                ip_parent, username_parent, password_parent, plaintext_login=True
            )
            api = connection.get_api()
            try:
                queue = api.get_resource('queue/simple/')
                queue_rate_upload = queue.get(
                    name=f"<pppoe-{pppoe_name}>")[0]['rate'].split('/')[0]
                queue_rate_download = queue.get(
                    name=f"<pppoe-{pppoe_name}>")[0]['rate'].split('/')[1]
                respon = jsonify(
                    {
                        "code": 200,
                        "status": "OK",
                        "data": {
                            'time': datetime.now().strftime('%H:%M:%S'),
                            "name": pppoe_name,
                            "rate": {
                                'upload': queue_rate_upload,
                                'download': queue_rate_download
                            }
                        }
                    }
                ), 200
                return respon
            except:
                pass
        finally:
            pass


@mod.route('/realtime/ping/bhome', methods=['GET', 'POST'])
@role_required(['Master', 'NOC', 'CR'])
@limiter.limit("30/minute")
def realtime_ping_bhome():
    get_id_customer = request.args.get('id_customer', type=str, default=None)

    if get_id_customer == "null":
        abort(403)

    connection = create_connection()
    data = selectTroubleshhotBhomeJoinTroubleshootParent(
        connection, get_id_customer)

    if data == None:
        abort(403)

    ip_client = data['ip_client']
    ip_parent = data['ip_parent']
    username_parent = data['username_parent']
    password_parent = data['password_parent']

    if ip_client != None:
        try:
            connection = routeros_api.RouterOsApiPool(
                ip_parent, username_parent, password_parent, plaintext_login=True
            )
            api = connection.get_api()
            try:
                command_ping = api.get_binary_resource(
                    '/').call('ping', {'address': str(ip_client).encode(), 'count': b'3', 'interval': b'0.3'})
                for ping in command_ping:
                    try:
                        result_ping = {
                            "min-rtt": str(ping['min-rtt'], 'UTF-8'),
                            "avg-rtt": str(ping['avg-rtt'], 'UTF-8'),
                            "max-rtt": str(ping['max-rtt'], 'UTF-8'),
                            "packet-loss": str(ping['packet-loss'], 'UTF-8'),
                        }
                    except:
                        result_ping = {
                            "status": str(ping['status'], 'UTF-8'),
                            "packet-loss": str(ping['packet-loss'], 'UTF-8'),
                        }

                respon = jsonify(
                    {
                        "code": 200,
                        "status": "OK",
                        "data": {
                            'time': datetime.now().strftime('%H:%M:%S'),
                            "ping": result_ping
                        }
                    }
                ), 200
                return respon
            except:
                pass
        finally:
            pass


@mod.route('/bcorp', methods=['GET', 'POST'])
@role_required(['Master', 'NOC', 'CR'])
@limiter.limit("30/minute")
def middleware_bcorp():
    connection = create_connection()
    get_keyword = request.args.get('id_customer', type=str, default=None)
    get_action = request.args.get('action', type=str, default=None)

    if get_action == "update":
        list_router = selectAuthenticationJoinTroubleshootParent(connection)
        countClient = 0

        for parrent in list_router:
            parent_id = parrent['ID_Parent']
            parent_ip_address = parrent['IP_Address']
            parent_port_ssh = parrent['Port_API']
            parent_username = parrent['Username']
            parent_password = parrent['Password']
            parent_category = parrent['Category']

            if parent_category == 'bcorp':
                try:
                    connection_parent = routeros_api.RouterOsApiPool(
                        parent_ip_address, parent_username, parent_password, plaintext_login=True)
                    api = connection_parent.get_api()

                    queue = api.get_resource("/queue/simple")
                    queue_all = queue.get()
                    for x in queue_all:
                        if x['disabled'] == 'false':
                            try:
                                queue_id_customer = x['name']
                                queue_name = x['comment']
                                queue_limitation_upload = round(
                                    (int(str(x['max-limit']).split('/')[0]) / 1000) / 1000)
                                queue_limitation_download = round(
                                    (int(str(x['max-limit']).split('/')[1]) / 1000) / 1000)
                                queue_limitation = str(
                                    queue_limitation_upload) + "Mbps" + "/" + str(queue_limitation_download) + "Mbps"
                                queue_package = "Dedicated" if queue_limitation_upload == queue_limitation_download else "UpTo"
                                queue_ip_address_raw = str(x['target']).replace(
                                    '/32', '').replace('/30', '')
                                queue_ip_address = queue_ip_address_raw.split(',')[
                                    0]
                                insertBcorp(connection=connection, id_customer=queue_id_customer, name=queue_name,
                                            package=queue_package, limitation=queue_limitation, ip_address=queue_ip_address, id_parent=parent_id)
                                countClient += 1
                            except:
                                continue

                except:
                    pass
        respon = jsonify(
            {
                "code": 200,
                "status": "OK",
                "data": f"Insert {countClient} Done",
            }
        ), 200

        return respon
    elif get_action == 'delete':
        deleteAllBcorp(connection)
        respon = jsonify(
            {
                "code": 200,
                "status": "OK",
                "message": "DELETE ALL BCORP",
            }
        ), 200

        return respon

    if get_keyword:
        data = selectBcorp(connection, get_keyword)
        respon = jsonify(
            {
                "code": 200,
                "status": "OK",
                "data": data
            }
        ), 200

        return respon

    all_data = selectAllBcorp(connection)
    respon = jsonify(
        {
            "code": 200,
            "status": "OK",
            "data": all_data,
            "page": {
                "size": len(all_data),
                "total": 100,
                "totalPages": 5,
                "current": 1
            }
        }
    ), 200

    return respon


@mod.route('/realtime/queue/bcorp', methods=['GET', 'POST'])
@role_required(['Master', 'NOC', 'CR'])
@limiter.limit("30/minute")
def realtime_queue_bcorp():
    get_id_customer = request.args.get('id_customer', type=str, default=None)

    if get_id_customer == "null":
        abort(403)

    connection = create_connection()
    data = selectTroubleshootBcorpJoinTroubleshootParent(
        connection, get_id_customer)

    if data == None:
        abort(403)

    id_customer = data['ID_Customer']
    ip_parent = data['ip_parent']
    username_parent = data['username_parent']
    password_parent = data['password_parent']

    if id_customer != None:
        try:
            connection = routeros_api.RouterOsApiPool(
                ip_parent, username_parent, password_parent, plaintext_login=True
            )
            api = connection.get_api()
            try:
                queue = api.get_resource('queue/simple/')
                queue_rate_upload = queue.get(name=id_customer)[
                    0]['rate'].split('/')[0]
                queue_rate_download = queue.get(name=id_customer)[
                    0]['rate'].split('/')[1]

                try:
                    queue_rate_upload_int = queue.get(
                        name=id_customer + "_INT")[0]['rate'].split('/')[0]
                    queue_rate_download_int = queue.get(
                        name=id_customer + "_INT")[0]['rate'].split('/')[1]

                    queue_rate_upload_iix = queue.get(
                        name=id_customer + "_IIX")[0]['rate'].split('/')[0]
                    queue_rate_download_iix = queue.get(
                        name=id_customer + "_IIX")[0]['rate'].split('/')[1]

                    queue_rate_upload_bnix = queue.get(
                        name=id_customer + "_BNIX")[0]['rate'].split('/')[0]
                    queue_rate_download_bnix = queue.get(
                        name=id_customer + "_BNIX")[0]['rate'].split('/')[1]
                except:
                    queue_rate_upload_int = "null"
                    queue_rate_download_int = "null"

                    queue_rate_upload_iix = "null"
                    queue_rate_download_iix = "null"

                    queue_rate_upload_bnix = "null"
                    queue_rate_download_bnix = "null"

                respon = jsonify(
                    {
                        "code": 200,
                        "status": "OK",
                        "data": {
                            'time': datetime.now().strftime('%H:%M:%S'),
                            "name": id_customer,
                            "rate": {
                                'upload': queue_rate_upload,
                                'download': queue_rate_download,
                                'upload_int': queue_rate_upload_int,
                                'download_int': queue_rate_download_int,
                                'upload_iix': queue_rate_upload_iix,
                                'download_iix': queue_rate_download_iix,
                                'upload_bnix': queue_rate_upload_bnix,
                                'download_bnix': queue_rate_download_bnix
                            }
                        }
                    }
                ), 200

                return respon
            except:
                pass
        finally:
            pass

@mod.route('/snmp/olt', methods=['GET', 'POST'])
@role_required(['Master', 'NOC', 'CR'])
# @limiter.limit("30/minute")
def snmp_olt():
    get_id_customer = request.args.get('id_customer', type=str, default=None)

    if get_id_customer == "null":
        abort(403)

    connection = create_connection()
    data = selectTroubleshhotBhomeJoinTroubleshootParent(connection, get_id_customer)

    if data is None:
        abort(403)

    id_noc = int(data['ID_Noc'])
    ip_olt = data['ip_olt']
    if id_noc:
        ID_NOC = id_noc
        NUMBER_PORT = int(str(ID_NOC)[1:3])
        NUMBER_PORT_ONU = int(str(ID_NOC)[3:5])

        if NUMBER_PORT > 67:
            NUMBER_PORT -= 66
        elif NUMBER_PORT >= 51:
            NUMBER_PORT -= 50

        NUMBER_PORT = str(NUMBER_PORT)

        DICT_OID = {
            'ONU': {
                'STATE': str(CONSTANTS.CONSTANT_OIDS['ONU']['STATE']) + str(CONSTANTS.CONSTANT_OID_PORT_ALL['port'][NUMBER_PORT]['OID']) + '.' + str(NUMBER_PORT_ONU),
                'REDAMAN': {
                    'rx': str(CONSTANTS.CONSTANT_OIDS['ONU']['REDAMAN']['rx']) + str(CONSTANTS.CONSTANT_OID_PORT_ALL['port'][NUMBER_PORT]['OID']) + '.' + str(NUMBER_PORT_ONU) + '.1'
                },
                'AUTHPASS': str(CONSTANTS.CONSTANT_OIDS['ONU']['AUTHPASS']) + str(CONSTANTS.CONSTANT_OID_PORT_ALL['port'][NUMBER_PORT]['OID']) + '.' + str(NUMBER_PORT_ONU),
                'OFFLINE': str(CONSTANTS.CONSTANT_OIDS['ONU']['OFFLINE']) + str(CONSTANTS.CONSTANT_OID_PORT_ALL['port'][NUMBER_PORT]['OID']) + '.' + str(NUMBER_PORT_ONU),
                'TYPE': str(CONSTANTS.CONSTANT_OIDS['ONU']['TYPE']) + str(CONSTANTS.CONSTANT_OID_PORT_ALL['port'][NUMBER_PORT]['OID']) + '.' + str(NUMBER_PORT_ONU),
                'NAME': str(CONSTANTS.CONSTANT_OIDS['ONU']['NAME']) + str(CONSTANTS.CONSTANT_OID_PORT_ALL['port'][NUMBER_PORT]['OID']) + '.' + str(NUMBER_PORT_ONU),
                'SN': str(CONSTANTS.CONSTANT_OIDS['ONU']['SN']) + str(CONSTANTS.CONSTANT_OID_PORT_ALL['port'][NUMBER_PORT]['OID']) + '.' + str(NUMBER_PORT_ONU),
            }
        }

        get_onu_state = SNMP_GET(ip_olt, 'intbnet', DICT_OID['ONU']['STATE'])
        get_onu_redaman_rx = (SNMP_GET(ip_olt, 'intbnet', DICT_OID['ONU']['REDAMAN']['rx']) * 0.002 - 30)
        get_onu_redaman_rx_result = get_onu_redaman_rx - 131.07 if get_onu_redaman_rx > 90 else get_onu_redaman_rx
        get_onu_authpass = SNMP_GET(ip_olt, 'intbnet', DICT_OID['ONU']['AUTHPASS'])
        get_onu_offline = SNMP_GET(ip_olt, 'intbnet', DICT_OID['ONU']['OFFLINE'])
        get_onu_type = SNMP_GET(ip_olt, 'intbnet', DICT_OID['ONU']['TYPE'])
        get_onu_name = SNMP_GET(ip_olt, 'intbnet', DICT_OID['ONU']['NAME'])
        get_onu_sn = SNMP_GET(ip_olt, 'intbnet', DICT_OID['ONU']['SN'])

        if get_onu_state == 0:
            get_onu_state = "Logging"
        elif get_onu_state == 1:
            get_onu_state = "Los"
        elif get_onu_state == 2:
            get_onu_state = "SynMiB"
        elif get_onu_state == 3:
            get_onu_state = "Working"
        elif get_onu_state == 4:
            get_onu_state = "DyingGasp"
        elif get_onu_state == 5:
            get_onu_state = "AuthFailed"
        elif get_onu_state == 6:
            get_onu_state = "Offline"

        if str(get_onu_type.decode('utf-8')) == "FD514GD-R460":
            serial_number_patern = "DF18"
        else:
            serial_number_patern = "ZTEG"

        RESULT_CHECKER = {
            'onu': {
                'state': str(get_onu_state),
                'redaman': {
                    'rx': str(round(get_onu_redaman_rx_result, 2)) + ' dBm'
                },
                'authpass': str(get_onu_authpass.decode('utf-8')),
                'offline': str(get_onu_offline.decode('utf-8')),
                'type': str(get_onu_type.decode('utf-8')),
                'name': str(get_onu_name.decode('utf-8')),
                'serial_number': serial_number_patern + str(get_onu_sn.hex()[8:]).upper()
            }
        }

        return jsonify(
            {
                "code": 200,
                "status": "OK",
                "data": RESULT_CHECKER
            }
        ), 200

@mod.route('/crawler', methods=['GET', 'POST'])
@role_required(['Master', 'NOC', 'CR'])
@limiter.limit("30/minute")
def crawler_device():
    # Get Parameter From URL
    get_ip_address = request.args.get('ip_address', type=str)

    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.chrome.service import Service
    from webdriver_manager.chrome import ChromeDriverManager
    import time
    import re

    url = F"http://{get_ip_address}/"
    option = Options()  # webdriver.ChromeOptions()
    #option.binary_location = brave_path

    option.add_argument(
        '--user-agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36')
    option.add_argument("--incognito")  # OPTIONAL
    option.add_argument("--headless")  # OPTIONAL
    option.add_argument('--no-sandbox')
    option.add_argument('--disable-dev-shm-usage')
    option.add_argument("--disable-popup-blocking")

    # Create new Instance of Chrome
    browser = webdriver.Chrome(service=Service(
        ChromeDriverManager().install()), options=option)
    browser.get(url)
    time.sleep(0.5)
    device_type = browser.title

    if device_type == "F623" or device_type == "F609" or device_type == "F660":

        if device_type == "F623" or device_type == "F660":
            # Input Username
            browser.find_element(
                "xpath", '//*[@id="Frm_Username"]').send_keys("admin")
            # Input Password
            browser.find_element(
                "xpath", '//*[@id="Frm_Password"]').send_keys("bhomepastimaju")
        elif device_type == "F609":
            # Input Username
            browser.find_element(
                "xpath", '//*[@id="Frm_Username"]').send_keys("user")
            # Input Password
            browser.find_element(
                "xpath", '//*[@id="Frm_Password"]').send_keys("bhomepastimaju123")

        # Button Login
        browser.find_element("xpath", '//*[@id="LoginId"]').click()

        # Page WLAN > SSID
        browser.get(
            f"{url}getpage.gch?pid=1002&nextpage=net_wlanm_essid1_t.gch")
        get_wlan_ssid = re.findall(
            'id="ESSID" value="(.+)"', str(browser.page_source))[0]

        # Page WLAN > Security
        browser.get(
            f"{url}getpage.gch?pid=1002&nextpage=net_wlanm_secrity1_t.gch")
        get_wlan_pass = re.findall(
            'id="KeyPassphrase" value="(.+)"', str(browser.page_source))[0]

        # Page WLAN > Associated Device
        browser.get(
            f"{url}getpage.gch?pid=1002&nextpage=net_wlanm_assoc1_t.gch")
        get_count_device = len(re.findall(
            '<tr class="white" classname="white">', str(browser.page_source)))

    elif device_type == "TOTOLINK":
        device_version = re.findall('V9.3.5u.\d+', str(browser.page_source))[0]

        if device_version == "V9.3.5u.6139":
            # Input Password
            browser.find_element(
                "xpath", '//*[@id="loginfrm"]/div/table/tr[1]/td/div[1]/input').send_keys("bhomepastimaju")
            # Button Login
            browser.find_element(
                "xpath", '/html/body/div/div[2]/div/div[1]/form/div/table/tr[1]/td/div[1]/button').click()

            browser.get(f"{url}advance/wifi.html")
            time.sleep(0.5)
            get_wlan_ssid = browser.find_element(
                "xpath", '/html/body/div/div[2]/div[2]/div[1]/div[2]/div[2]/table[2]/tbody[2]/tr/td[2]/input').get_attribute('value')
            get_wlan_pass = browser.find_element(
                "xpath", '/html/body/div/div[2]/div[2]/div[1]/div[2]/div[2]/table[2]/tbody[4]/tr/td[2]/input').get_attribute('value')
            browser.get(f"{url}basic/device.html")
            time.sleep(0.5)
            get_count_device = len(re.findall(
                '<tr>', str(browser.page_source))) - 10
        elif device_version == "V9.3.5u.6095":
            # Input Password
            browser.find_element(
                "xpath", '//*[@id="password"]').send_keys("bhomepastimaju")
            # Button Login
            browser.find_element(
                "xpath", '//*[@id="loginfrm"]/div/table/tr[1]/td/div[1]/button').click()

            browser.get(f"{url}advance/wifi.html")
            time.sleep(0.5)
            get_wlan_ssid = browser.find_element(
                "xpath", '/html/body/div/div[2]/div[2]/div[1]/div[2]/div[2]/table[2]/tbody[2]/tr/td[2]/input').get_attribute('value')
            get_wlan_pass = browser.find_element(
                "xpath", '/html/body/div/div[2]/div[2]/div[1]/div[2]/div[2]/table[2]/tbody[3]/tr/td[2]/input').get_attribute('value')
            browser.get(f"{url}basic/device.html")
            time.sleep(0.5)
            get_count_device = len(re.findall(
                '<tr>', str(browser.page_source))) - 10
    elif device_type == 'F670L':
        # Input Username
        browser.find_element(
            "xpath", '//*[@id="Frm_Username"]').send_keys("user")
        # Input Password
        browser.find_element(
            "xpath", '//*[@id="Frm_Password"]').send_keys("bhomepastimaju123")
        # Button Login
        browser.find_element("xpath", '//*[@id="LoginId"]').click()
        time.sleep(1.5)
        # Menu WlAN Setting
        browser.find_element("xpath", '//*[@id="localnet"]').click()
        time.sleep(0.5)
        browser.find_element("xpath", '//*[@id="Wlan_ClientStatBar"]').click()
        get_count_device = browser.find_element(
            "xpath", '/html/body/div[3]/div[2]/div[1]/div[3]/div[2]/div[2]/div/div[3]/div[2]/form/div[1]/div[1]').get_attribute('childElementCount')
        time.sleep(0.5)
        browser.find_element("xpath", '//*[@id="wlanConfig"]').click()
        time.sleep(0.5)
        browser.find_element("xpath", '//*[@id="WLANSSIDConfBar"]').click()
        get_wlan_ssid = browser.find_element(
            "xpath", '/html/body/div[3]/div[2]/div[1]/div[3]/div[2]/div[2]/div/div[3]/div[2]/div[1]/form/div[2]/div[3]/div[1]/div/input').get_attribute('value')
        get_wlan_pass = browser.find_element(
            "xpath", '/html/body/div[3]/div[2]/div[1]/div[3]/div[2]/div[2]/div/div[3]/div[2]/div[1]/form/div[2]/div[3]/div[4]/div/input[1]').get_attribute('value')
    else:
        respon = jsonify(
            {
                "code": 404,
                "status": "NOT_FOUND",
                "message": "Device Not Found",
                "error": "Not Found"
            }
        ), 404
        return respon

    respon = jsonify(
        {
            "code": 200,
            "status": "OK",
            "data": {
                "wlan_ssid": str(get_wlan_ssid).replace('\\x20', ' '),
                "wlan_pass": str(get_wlan_pass).replace('\\x20', ' '),
                "wlan_associated": get_count_device
            }
        }
    ), 200
    return respon
