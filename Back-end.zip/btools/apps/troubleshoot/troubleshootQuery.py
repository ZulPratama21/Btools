from btools import mysql as MYSQL
import pymysql


def create_connection():
    connection = None
    try:
        connection = MYSQL.connect()
    except Exception as e:
        print(e)
    return connection

def selectAuthenticationJoinTroubleshootParent(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(""" 
    SELECT * FROM authentication INNER JOIN troubleshoot_parent ON authentication.ID_Authentication = troubleshoot_parent.ID_Authentication;
    """)
    rows = cursor.fetchall()

    return rows

def selectAuthenticationJoinTroubleshootOlt(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(""" 
    SELECT * FROM authentication
    INNER JOIN troubleshoot_olt
    ON authentication.ID_Authentication = troubleshoot_olt.ID_Authentication
    """)
    rows = cursor.fetchall()

    return rows

def selectTroubleshhotBhomeJoinTroubleshootParent(connection, id_customer):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(f""" 
    SELECT troubleshoot_bhome.ID_Customer, troubleshoot_bhome.Secret_User, troubleshoot_bhome.ID_Noc, troubleshoot_bhome.IP_Address as 'ip_client', troubleshoot_parent.IP_Address as 'ip_parent', troubleshoot_olt.IP_Address as 'ip_olt', authentication.Username AS username_parent, authentication.`Password` AS password_parent
    FROM troubleshoot_bhome
    INNER JOIN troubleshoot_parent
    ON troubleshoot_bhome.ID_Parent = troubleshoot_parent.ID_Parent
    INNER JOIN troubleshoot_olt
    ON troubleshoot_bhome.ID_OLT = troubleshoot_olt.ID_OLT
    INNER JOIN authentication
    ON authentication.ID_Authentication = troubleshoot_parent.ID_Authentication
    WHERE troubleshoot_bhome.ID_Customer='{id_customer}'
    """)
    rows = cursor.fetchone()

    return rows

"""
Entity : troubleshoot_parent
"""
def selectAllParent(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM `troubleshoot_parent`")
    rows = cursor.fetchall()

    return rows

"""
Entity : troubleshoot_olt
"""
def selectAllOlt(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM `troubleshoot_olt`")
    rows = cursor.fetchall()

    return rows

"""
Entity : troubleshoot_bhome
"""
def selectAllBhome(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        f"SELECT * FROM troubleshoot_bhome")
    rows = cursor.fetchall()

    return rows

def selectBhome(connection, get_keyword):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        f"""SELECT * FROM troubleshoot_bhome WHERE CONCAT('.', ID_Customer, '.', ID_Noc, '.', Name, '.', IP_Address, '.', Secret_User, '.') LIKE ".%{get_keyword}%.";""")
    rows = cursor.fetchone()

    return rows

def insertBhome(connection, id_customer, name, id_noc, secret_user, limitation, ip_address, id_parent, id_olt):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(f"""
    INSERT INTO `troubleshoot_bhome` (`ID_Customer`, `Name`, `ID_Noc`, `Secret_User`, `Limitation`, `IP_Address`, `ID_Parent`, `ID_OLT`) 
    VALUES ('{id_customer}', '{name}', '{id_noc}', '{secret_user}', '{limitation}', '{ip_address}', '{id_parent}', '{id_olt}');
    """)
    connection.commit()

    return None

def deleteAllBhome(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute("DELETE FROM troubleshoot_bhome")
    connection.commit()

    return None

"""
Entity : troubleshoot_bcorp
"""
def selectAllBcorp(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        f"SELECT * FROM troubleshoot_bcorp")
    rows = cursor.fetchall()

    return rows

def selectBcorp(connection, get_keyword):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        f"""SELECT * FROM troubleshoot_bcorp WHERE CONCAT('.', ID_Customer, '.', Name, '.', IP_Address, '.') LIKE ".%{get_keyword}%.";""")
    rows = cursor.fetchone()

    return rows

def insertBcorp(connection, id_customer, name, limitation, package, ip_address, id_parent):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(f"""
    INSERT INTO `troubleshoot_bcorp` (`ID_Customer`, `Name`, `Limitation`, `Package`, `IP_Address`, `ID_Parent`) 
    VALUES ('{id_customer}', '{name}', '{limitation}', '{package}', '{ip_address}', '{id_parent}');
    """)
    connection.commit()

    return None

def deleteAllBcorp(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute("DELETE FROM troubleshoot_bcorp")
    connection.commit()

    return None

def selectTroubleshootBcorpJoinTroubleshootParent(connection, id_customer):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(f""" 
    SELECT troubleshoot_bcorp.ID_Customer, troubleshoot_bcorp.IP_Address as 'ip_client', troubleshoot_parent.IP_Address as 'ip_parent', authentication.Username AS username_parent, authentication.`Password` AS password_parent FROM troubleshoot_bcorp
    INNER JOIN troubleshoot_parent
    ON troubleshoot_bcorp.ID_Parent = troubleshoot_parent.ID_Parent
    INNER JOIN authentication
    ON authentication.ID_Authentication = troubleshoot_parent.ID_Authentication
    WHERE troubleshoot_bcorp.ID_Customer='{id_customer}';
    """)
    rows = cursor.fetchone()

    return rows
