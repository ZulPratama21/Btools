from flask import Blueprint, render_template, request, redirect, flash
from btools.apps.troubleshoot.troubleshootQuery import *
from btools import role_required

mod = Blueprint('troubleshoot', __name__, url_prefix='/troubleshoot')

@mod.route('/bhome', methods=['GET', 'POST'])
@role_required(['Master', 'NOC', 'CR'])
def index_bhome():
    connection = create_connection()
    if request.method == 'POST':
        data = selectBhome(connection, str(
            request.form['keyword']).strip().replace('"', ''))
        if data:
            return redirect(f'/public/troubleshoot/bhome?id_customer={data["ID_Customer"]}')
        else:
            flash(
                f'❌ {str(request.form["keyword"]).strip()} tidak ditemukan', 'danger')
    return render_template("troubleshoot/Bhome.html")


@mod.route('/bcorp', methods=['GET', 'POST'])
@role_required(['Master', 'NOC', 'CR'])
def index_bcorp():
    connection = create_connection()
    if request.method == 'POST':
        data = selectBcorp(connection, str(
            request.form['keyword']).strip().replace('"', ''))
        if data:
            return redirect(f'/public/troubleshoot/bcorp?id_customer={data["ID_Customer"]}')
        else:
            flash(
                f'❌ {str(request.form["keyword"]).strip()} tidak ditemukan', 'danger')
    return render_template("troubleshoot/Bcorp.html")
