from flask import Blueprint, render_template, request, redirect, flash
from btools import role_required
from btools.apps.troubleshoot.troubleshootQuery import create_connection, selectBhome

mod = Blueprint('monitoring', __name__, url_prefix='/monitoring')

@mod.route('/wireless', methods=['GET'])
@role_required(['Master', 'NOC'])
def index_wireless():
    return render_template("monitoring/WirelessDiscovery.html")

@mod.route('/mrtg/link/metro_transit', methods=['GET'])
@role_required(['Master', 'NOC'])
def index_mrtg_link_metro_transit():
    return render_template("monitoring/MrtgLinkTransit.html")

@mod.route('/mrtg/cpu', methods=['GET'])
@role_required(['Master', 'NOC'])
def index_mrtg_cpu():
    return render_template("monitoring/MrtgCpu.html")

@mod.route('/periodic', methods=['GET'])
@role_required(['Master', 'NOC'])
def index_periodic():
    return render_template("monitoring/PeriodicChecking.html")

@mod.route('/redaman/bhome', methods=['GET', 'POST'])
@role_required(['Master', 'NOC'])
def index_redaman_bhome():
    connection = create_connection()
    if request.method == 'POST':
        data = selectBhome(connection, str(request.form['keyword']).strip().replace('"', ''))
        if data:
            return redirect(f'/public/monitoring/redaman/bhome?id_customer={data["ID_Customer"]}')
        else:
             flash(f'❌ {str(request.form["keyword"]).strip()} tidak ditemukan', 'danger')
    return render_template("monitoring/RedamanBhome.html")

@mod.route('/modem', methods=['GET', 'POST'])
@role_required(['Master', 'NOC'])
def index_modem():
    connection = create_connection()
    if request.method == 'POST':
        data = selectBhome(connection, str(request.form['keyword']).strip().replace('"', ''))
        if data:
            return redirect(f'/public/monitoring/redaman/bhome?id_customer={data["ID_Customer"]}')
        else:
             flash(f'❌ {str(request.form["keyword"]).strip()} tidak ditemukan', 'danger')
    return render_template("monitoring/AllModem.html")