from flask import Blueprint, jsonify, request
from flask import jsonify
from btools import limiter, role_required
from btools.apps.monitoring.monitoringQuery import *

mod = Blueprint('monitoring', __name__, url_prefix='/monitoring')

"""
Menu : Wireless Discovery 
"""


@mod.route('/wireless/', methods=['GET'])
@role_required(['Master', 'NOC'])
def api_wireless_all():
    connection = create_connection()
    all_data = selectAllWireless(connection)
    countRestrictedFrequency = selectCountRestrictedAccessPoint(connection)
    countCCQLow = selectCountCCQLowRadioStation(connection)
    countHighSignal = selectCountHighSignalRadioStation(connection)
    respon = jsonify(
        {
            "code": 200,
            "status": "OK",
            "data": {
                "all_wireless": all_data,
                "quickInfo": countRestrictedFrequency + countCCQLow + countHighSignal
            },
            "page": {
                "size": len(all_data),
                "total": 100,
                "totalPages": 5,
                "current": 1
            }
        }
    ), 200
    return respon


@mod.route('/wireless/radio', methods=['GET', 'POST', 'PUT', 'DELETE'])
@role_required(['Master', 'NOC'])
def api_wireless_radio():
    connection = create_connection()

    get_id_radio = request.args.get('id_radio', type=str)
    get_ip_address = request.args.get('ip_address', type=str, default=None)
    get_port_ssh = request.args.get('port_ssh', type=int, default=None)
    get_port_api = request.args.get('port_api', type=int, default=None)
    get_id_authentication = request.args.get('id_authentication', type=str)
    get_id_vendor = request.args.get('id_vendor', type=str)
    get_id_pop = request.args.get('id_pop', type=str)

    if request.method == 'POST':
        if selectRadio(connection, get_id_radio) != None:
            respon = jsonify(
                {
                    "code": 406,
                    "status": "Not_Acceptable",
                    "error": "Duplicate Data"
                }
            ), 406
            return respon

        insertRadio(connection, get_id_radio, get_ip_address, get_port_ssh,
                    get_port_api, get_id_authentication, get_id_vendor, get_id_pop)
        respon = jsonify(
            {
                "code": 201,
                "status": "Created",
                "data": selectRadio(connection, get_id_radio)
            }
        ), 201
        return respon
    elif request.method == 'PUT':
        if selectRadio(connection, get_id_radio) != None:
            updateRadio(connection, get_id_radio, get_ip_address, get_port_ssh,
                        get_port_api, get_id_authentication, get_id_vendor, get_id_pop)
            respon = jsonify(
                {
                    "code": 204,
                    "status": "NO_CONTENT",
                }
            ), 204
            return respon
        respon = jsonify(
            {
                "code": 404,
                "status": "NOT_FOUND",
                "error": "Not Found Data"
            }
        ), 404
        return respon
    elif request.method == 'DELETE':
        if selectRadio(connection, get_id_radio) != None:
            deleteRadio(connection, get_id_radio)
            respon = jsonify(
                {
                    "code": 204,
                    "status": "NO_CONTENT"
                }
            ), 204
            return respon
        respon = jsonify(
            {
                "code": 404,
                "status": "NOT_FOUND",
                "error": "Not Found Data"
            }
        ), 404
        return respon

    all_data = selectAllRadio(connection)
    respon = jsonify(
        {
            "code": 200,
            "status": "OK",
            "data": all_data,
            "page": {
                "size": len(all_data),
                "total": 100,
                "totalPages": 5,
                "current": 1
            }
        }
    ), 200
    return respon


@mod.route('/wireless/radio/accesspoint', methods=['GET', 'POST', 'PUT', 'DELETE'])
@role_required(['Master', 'NOC'])
def api_wireless_radio_accesspoint():
    connection = create_connection()

    get_id_radio = request.args.get('id_radio', type=str)
    get_board = request.args.get('board', type=str, default=None)
    get_ssid = request.args.get('ssid', type=str, default=None)
    get_serial_number = request.args.get(
        'serial_number', type=str, default=None)
    get_scan_list = request.args.get('scan_list', type=str, default=None)
    get_frequency = request.args.get('frequency', type=str, default=None)
    get_wireless_protocol = request.args.get(
        'wireless_protocol', type=str, default=None)
    get_band = request.args.get('band', type=str, default=None)
    get_channel_width = request.args.get(
        'channel_width', type=str, default=None)
    get_restricted_frequency = request.args.get(
        'restricted_frequency', type=int, default=None)

    if request.method == 'POST':
        if selectRadioAccesspoint(connection, get_id_radio) != None:
            respon = jsonify(
                {
                    "code": 406,
                    "status": "Not_Acceptable",
                    "error": "Duplicate Data"
                }
            ), 406
            return respon

        insertRadioAccessPoint(connection, get_id_radio, get_board, get_ssid,
                               get_serial_number, get_scan_list, get_frequency, get_wireless_protocol, get_band, get_channel_width, get_restricted_frequency)
        respon = jsonify(
            {
                "code": 201,
                "status": "Created",
                "data": selectRadioAccesspoint(connection, get_id_radio)
            }
        ), 201
        return respon
    elif request.method == 'PUT':
        if selectRadioAccesspoint(connection, get_id_radio) != None:
            updateRadioAccessPoint(connection, get_id_radio, get_board, get_ssid, get_serial_number, get_scan_list,
                                   get_frequency, get_wireless_protocol, get_band, get_channel_width, get_restricted_frequency)
            respon = jsonify(
                {
                    "code": 204,
                    "status": "NO_CONTENT",
                }
            ), 204
            return respon
        respon = jsonify(
            {
                "code": 404,
                "status": "NOT_FOUND",
                "error": "Not Found Data"
            }
        ), 404
        return respon
    elif request.method == 'DELETE':
        if selectRadioAccesspoint(connection, get_id_radio) != None:
            deleteRadioAccessPoint(connection, get_id_radio)
            respon = jsonify(
                {
                    "code": 204,
                    "status": "NO_CONTENT"
                }
            ), 204
            return respon
        respon = jsonify(
            {
                "code": 404,
                "status": "NOT_FOUND",
                "error": "Not Found Data"
            }
        ), 404
        return respon

    all_data = selectAllRadioAccesspoint(connection)
    respon = jsonify(
        {
            "code": 200,
            "status": "OK",
            "data": all_data,
            "page": {
                "size": len(all_data),
                "total": 100,
                "totalPages": 5,
                "current": 1
            }
        }
    ), 200
    return respon


@mod.route('/wireless/radio/station', methods=['GET', 'POST', 'PUT', 'DELETE'])
@role_required(['Master', 'NOC'])
def api_wireless_radio_station():
    connection = create_connection()

    get_id_station_name = request.args.get('id_station_name', type=str)
    get_board = request.args.get('board', type=str, default=None)
    get_mac = request.args.get('mac', type=str, default=None)
    get_signal_tx = request.args.get('signal_tx', type=int, default=None)
    get_signal_rx = request.args.get('signal_rx', type=int, default=None)
    get_ccq_tx = request.args.get('ccq_tx', type=int, default=None)
    get_ccq_rx = request.args.get('ccq_rx', type=int, default=None)
    get_station_distance = request.args.get(
        'station_distance', type=int, default=None)
    get_tunning_recomendation = request.args.get(
        'tunning_recomendation', type=int, default=None)
    get_id_radio = request.args.get('id_radio', type=str)

    if request.method == 'POST':
        insertRadioStation(connection, get_id_station_name, get_board, get_mac, get_signal_tx, get_signal_rx,
                           get_ccq_tx, get_ccq_rx, get_station_distance, get_tunning_recomendation, get_id_radio)
        respon = jsonify(
            {
                "code": 201,
                "status": "Created",
                "data": selectRadioStation(connection, get_id_station_name)
            }
        ), 201
        return respon
    elif request.method == 'DELETE':
        if selectRadioStation(connection, get_id_station_name) != None:
            deleteRadioStation(connection, get_id_station_name)
            respon = jsonify(
                {
                    "code": 204,
                    "status": "NO_CONTENT"
                }
            ), 204
            return respon
        respon = jsonify(
            {
                "code": 404,
                "status": "NOT_FOUND",
                "error": "Not Found Data"
            }
        ), 404
        return respon

    all_data = selectAllRadioStation(connection)
    respon = jsonify(
        {
            "code": 200,
            "status": "OK",
            "data": all_data,
            "page": {
                "size": len(all_data),
                "total": 100,
                "totalPages": 5,
                "current": 1
            }
        }
    ), 200
    return respon


"""
Menu : MRTG Link Transit
"""


@mod.route('/mrtg/ports', methods=['GET'])
@role_required(['Master', 'NOC'])
def mrtg_ports():
    connection = create_connection()
    all_data = selectAllMrtgPorts(connection)

    respon = jsonify(
        {
            "code": 200,
            "status": "OK",
            "data": {
                "all_ports": all_data
            },
            "page": {
                "size": len(all_data),
                "total": 100,
                "totalPages": 5,
                "current": 1
            }
        }
    ), 200
    return respon

"""
Menu : MRTG CPU
"""


@mod.route('/mrtg/cpu', methods=['GET'])
@role_required(['Master', 'NOC'])
def mrtg_cpu():
    connection = create_connection()
    all_data = selectAllMrtgCpu(connection)

    respon = jsonify(
        {
            "code": 200,
            "status": "OK",
            "data": {
                "all_ports": all_data
            },
            "page": {
                "size": len(all_data),
                "total": 100,
                "totalPages": 5,
                "current": 1
            }
        }
    ), 200
    return respon

"""
Menu : Periodic Checking
"""


@mod.route('/periodic', methods=['GET'])
@role_required(['Master', 'NOC'])
def periodic():
    connection = create_connection()
    all_data = selectAllLinkBackup(connection)

    respon = jsonify(
        {
            "code": 200,
            "status": "OK",
            "data": {
                "all_periodic": all_data
            },
            "page": {
                "size": len(all_data),
                "total": 100,
                "totalPages": 5,
                "current": 1
            }
        }
    ), 200
    return respon


"""
Menu : monitoring Bhome
"""

@mod.route('/bhome', methods=['GET'])
@role_required(['Master', 'NOC'])
def bhome():
    # Get Parameter From URL
    get_id_customer = request.args.get('id_customer', type=str, default=None)

    if get_id_customer == 'null':
        return jsonify({"code": 404, "status": "Not Found", "message": "Data not found"}), 404

    connection = create_connection()
    all_data = selectAllMonitoringBhome(connection)

    if get_id_customer:
        data = selectMonitoringBhome(connection, get_id_customer)
        if not data:
            return jsonify({"code": 404, "status": "Not Found", "message": "Data not found"}), 404
        else:
            page_size = len(data)
            respon = jsonify(
                {
                    "code": 200,
                    "status": "OK",
                    "data": data,
                    "page": {
                        "size": page_size,
                        "total": 100,
                        "totalPages": 5,
                        "current": 1
                    }
                }
            ), 200
            return respon

    page_size_all_data = len(all_data)
    respon = jsonify(
        {
            "code": 200,
            "status": "OK",
            "data": {
                "all_bhome": all_data,
                "Created_at": selectMaxTimeMonitoringBhome(connection)
            },
            "page": {
                "size": page_size_all_data,
                "total": 100,
                "totalPages": 5,
                "current": 1
            }
        }
    ), 200
    return respon


"""
Menu : monitoring All Modem
"""

@mod.route('/modem', methods=['GET'])
@role_required(['Master', 'NOC'])
def modem():
    # Get Parameter From URL
    get_id_noc = request.args.get('id_noc', type=str, default=None)

    connection = create_connection()

    if get_id_noc:
        data = selectMonitoringAllModem(connection, get_id_noc)
        if not data:
            return jsonify({"code": 404, "status": "Not Found", "message": "Data not found"}), 404
    else:
        data = selectAllMonitoringAllModem(connection)
        if not data:
            return jsonify({"code": 404, "status": "Not Found", "message": "Data not found"}), 404

    page_size = len(data)
    respon = jsonify(
        {
            "code": 200,
            "status": "OK",
            "data": {"all_modem": data} if not get_id_noc else data,
            "page": {
                "size": page_size,
                "total": 100,
                "totalPages": 5,
                "current": 1
            }
        }
    ), 200
    return respon
