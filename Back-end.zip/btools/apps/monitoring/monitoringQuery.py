from btools import mysql as MYSQL
import pymysql


def create_connection():
    connection = None
    try:
        connection = MYSQL.connect()
    except Exception as e:
        print(e)
    return connection


def selectAllWireless(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute("""
    SELECT 
    monitoringradio_radio.ID_Radio,
    monitoringradio_radio.ID_Vendor,
    monitoringradio_radio.ID_POP,
    monitoringradio_radio.IP_Address,
    monitoringradio_accesspoint.Board,
    monitoringradio_accesspoint.SSID,
    monitoringradio_accesspoint.Serial_Number,
    monitoringradio_accesspoint.Scan_List,
    monitoringradio_accesspoint.Frequency,
    monitoringradio_accesspoint.Wireless_Protocol,
    monitoringradio_accesspoint.Band,
    monitoringradio_accesspoint.Channel_Width,
    monitoringradio_accesspoint.Restricted_Frequency,
    monitoringradio_station.ID_Station_Name,
    DATE_FORMAT(monitoringradio_station.Created_at, '%d-%m-%Y %H:%i:%s') as Created_at,
    monitoringradio_station.Board,
    monitoringradio_station.Mac,
    MAX(monitoringradio_station.SignalTx) as SignalTx,
    MAX(monitoringradio_station.SignalRx) as SignalRx,
    monitoringradio_station.CCQTx,
    monitoringradio_station.CCQRx,
    monitoringradio_station.Station_Distance,
    monitoringradio_station.Tunning_Recomendation
    FROM monitoringradio_radio
    JOIN monitoringradio_accesspoint ON monitoringradio_radio.ID_Radio = monitoringradio_accesspoint.ID_Radio
    JOIN monitoringradio_station ON monitoringradio_accesspoint.SSID = monitoringradio_station.ID_Radio
    GROUP BY monitoringradio_station.ID_Station_Name
    """)
    rows = cursor.fetchall()

    return rows


def selectCountRestrictedAccessPoint(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        "SELECT COUNT(Restricted_Frequency) AS countRestrictedFrequency FROM monitoringradio_accesspoint WHERE Restricted_Frequency=1")
    rows = cursor.fetchall()

    return rows


def selectCountCCQLowRadioStation(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT COUNT(ID_Radio) as countLowCCQ FROM monitoringradio_station WHERE CCQTx <=50 AND CCQRx <=50 AND DATE_FORMAT(monitoringradio_station.Created_at, '%d-%m-%Y %H:%i:%s') >= DATE_SUB(DATE(NOW()), INTERVAL 14 DAY)")
    rows = cursor.fetchall()

    return rows


def selectCountHighSignalRadioStation(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT COUNT(ID_Station_Name) AS countHighSignal FROM monitoringradio_station WHERE SignalTx<-65 and SignalRx <-65 AND DATE_FORMAT(monitoringradio_station.Created_at, '%d-%m-%Y %H:%i:%s')  >= DATE_SUB(DATE(NOW()), INTERVAL 14 DAY)")
    rows = cursor.fetchall()

    return rows



"""
Entity : monitoringradio_radio
"""


def selectAllRadio(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM monitoringradio_radio ORDER BY ID_POP ASC")
    rows = cursor.fetchall()

    return rows


def selectRadio(connection, id_radio):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        f"SELECT id_radio FROM monitoringradio_radio WHERE id_radio='{id_radio}'")
    rows = cursor.fetchone()

    return rows


def insertRadio(connection, id_radio, ip_address, port_ssh, port_api, id_authentication, id_vendor, id_pop):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(f"""
    INSERT INTO monitoringradio_radio (`ID_Radio`, `IP_Address`, `Port_SSH`, `Port_API`, `ID_Authentication`, `ID_Vendor`, `ID_POP`) VALUES ('{id_radio}', '{ip_address}', '{port_ssh}', '{port_api}', '{id_authentication}', '{id_vendor}', '{id_pop}');
    """)
    connection.commit()

    return None


def updateRadio(connection, id_radio, ip_address, port_ssh, port_api, id_authentication, id_vendor, id_pop):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(f"""
    UPDATE monitoringradio_radio SET `IP_Address` = '{ip_address}', `Port_SSH` = '{port_ssh}', `Port_API` = '{port_api}', `ID_Authentication` = '{id_authentication}', `ID_Vendor` = '{id_vendor}', `ID_POP`= '{id_pop}' WHERE ID_Radio= '{id_radio}';
    """)
    connection.commit()

    return None


def deleteRadio(connection, id_radio):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        f"DELETE FROM monitoringradio_radio WHERE `ID_Radio`='{id_radio}';")
    connection.commit()

    return None


"""
Entity : monitoringradio_accesspoints
"""


def selectAllRadioAccesspoint(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        "SELECT * FROM monitoringradio_accesspoint ORDER BY ID_Radio ASC")
    rows = cursor.fetchall()

    return rows


def selectRadioAccesspoint(connection, id_radio):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        f"SELECT id_radio FROM monitoringradio_accesspoint WHERE id_radio='{id_radio}'")
    rows = cursor.fetchone()

    return rows


def insertRadioAccessPoint(connection, id_radio, board, ssid, serial_number, scan_list, frequency, wireless_protocol, band, channel_width, restricted_frequency):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(f"""
    INSERT INTO monitoringradio_accesspoint (`ID_Radio`, `Board`, `SSID`, `Serial_Number`, `Scan_List`, `Frequency`, `Wireless_Protocol`, `Band`, `Channel_Width`, `Restricted_Frequency`) VALUES ('{id_radio}', '{board}', '{ssid}', '{serial_number}', '{scan_list}', '{frequency}', '{wireless_protocol}', '{band}', '{channel_width}', '{restricted_frequency}');
    """)
    connection.commit()

    return None


def updateRadioAccessPoint(connection, id_radio, board, ssid, serial_number, scan_list, frequency, wireless_protocol, band, channel_width, restricted_frequency, tunning_recomendation):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(f"""
    UPDATE monitoringradio_accesspoint SET `Board`='{board}', `SSID`='{ssid}', `Serial_Number`='{serial_number}', `Scan_List`='{scan_list}', `Frequency`='{frequency}', `Wireless_Protocol`='{wireless_protocol}', `Band`='{band}', `Channel_Width`='{channel_width}', `Restricted_Frequency`='{restricted_frequency}' WHERE ID_Radio= '{id_radio}';
    """)
    connection.commit()

    return None


def deleteRadioAccessPoint(connection, id_radio):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        f"DELETE FROM monitoringradio_accesspoint WHERE `ID_Radio`='{id_radio}';")
    connection.commit()

    return None


"""
Entity : monitoringradio_station
"""


def selectAllRadioStation(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        "SELECT * FROM monitoringradio_station ORDER BY ID_Station_Name ASC")
    rows = cursor.fetchall()

    return rows


def selectRadioStation(connection, id_station_Name):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        f"SELECT ID_Station_Name FROM monitoringradio_station WHERE ID_Station_Name='{id_station_Name}'")
    rows = cursor.fetchone()

    return rows


def insertRadioStation(connection, id_station_Name, board, mac, signal_tx, signal_rx, ccq_tx, ccq_rx, station_distance, tunning_recomendation, id_radio):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(f"""
    INSERT INTO `monitoringradio_station` (`ID_Station_Name`, `Board`, `Mac`, `SignalTx`, `SignalRx`, `CCQTx`, `CCQRx`, `Station_Distance`, `Tunning_Recomendation`, `ID_Radio`) VALUES ('{id_station_Name}', '{board}', '{mac}', '{signal_tx}', '{signal_rx}', '{ccq_tx}', '{ccq_rx}', '{station_distance}', '{tunning_recomendation}' ,'{id_radio}');
    """)
    connection.commit()

    return None


def deleteRadioStation(connection, id_station_Name):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        f"DELETE FROM monitoringradio_station WHERE `ID_Station_Name`='{id_station_Name}';")
    connection.commit()

    return None


"""
Entity : mrtg_ports
"""


def selectAllMrtgPorts(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        "SELECT * FROM mrtg_ports ORDER BY ID_Ports ASC")
    rows = cursor.fetchall()

    return rows

"""
Entity : mrtg_cpu
"""


def selectAllMrtgCpu(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        "SELECT * FROM mrtg_device_processor ORDER BY ID_Device_Processor ASC")
    rows = cursor.fetchall()

    return rows

"""
Entity : monitoring_bhome
"""
def selectMaxTimeMonitoringBhome(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(""" 
    SELECT MAX(DATE_FORMAT(Created_at, '%d %b %Y %H:%i:%s')) AS Created_at
    FROM monitoring_bhome;
    """)
    rows = cursor.fetchone()

    return rows

def selectCountLosBhome(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(""" 
    SELECT SUM(Jumlah_LOS) AS Total_Jumlah_LOS
    FROM (
        SELECT monitoring_bhome.ID_Customer, ID_Noc, State, Redaman, DATE_FORMAT(Offline, '%Y-%m-%d %H:%i:%s') as Offline, MAX(Created_at) AS Created_at,
            (SELECT COUNT(*) FROM troubleshoot_bhome WHERE State = 'LOS' AND troubleshoot_bhome.ID_Customer = monitoring_bhome.ID_Customer) AS Jumlah_LOS
        FROM monitoring_bhome
        INNER JOIN troubleshoot_bhome ON troubleshoot_bhome.ID_Customer = monitoring_bhome.ID_Customer
        GROUP BY ID_Customer
    ) AS subquery;

    """)
    rows = cursor.fetchall()

    return rows

def selectCountDyinggaspBhome(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(""" 
    SELECT SUM(Jumlah_Dyinggasp) AS Total_Jumlah_Dyinggasp
    FROM (
        SELECT monitoring_bhome.ID_Customer, ID_Noc, State, Redaman, DATE_FORMAT(Offline, '%d-%m-%Y %H:%i:%s') as Offline, MAX(DATE_FORMAT(Created_at, '%d-%m-%Y %H:%i:%s')) AS Created_at,
            (SELECT COUNT(*) FROM troubleshoot_bhome WHERE State = 'DyingGasp' AND troubleshoot_bhome.ID_Customer = monitoring_bhome.ID_Customer) AS Jumlah_Dyinggasp
        FROM monitoring_bhome
        INNER JOIN troubleshoot_bhome ON troubleshoot_bhome.ID_Customer = monitoring_bhome.ID_Customer
        GROUP BY ID_Customer
    ) AS subquery;
    """)
    rows = cursor.fetchall()

    return rows

def selectAllMonitoringBhome(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute("""
    SELECT t.ID_Noc, m.ID_Customer, m.State, m.Redaman, 
    DATE_FORMAT(m.Offline, '%d-%m-%Y %H:%i:%s') as Offline,
    DATE_FORMAT(m.Created_at, '%d-%m-%Y %H:%i:%s') as Created_at 
    FROM monitoring_bhome m
    INNER JOIN troubleshoot_bhome t
    ON t.ID_Customer = m.ID_Customer
    GROUP BY m.ID_Customer
    ORDER BY MAX(m.Created_at) DESC
    LIMIT 50
    """)
    rows = cursor.fetchall()

    return rows


def selectMonitoringBhome(connection, id_customer):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute("""
    SELECT t.ID_Noc, m.ID_Customer, m.State, m.Redaman, 
    DATE_FORMAT(m.Offline, '%%d-%%m-%%Y %%H:%%i:%%s') as Offline,
    DATE_FORMAT(m.Created_at, '%%d-%%m-%%Y %%H:%%i:%%s') as Created_at 
    FROM monitoring_bhome m
    INNER JOIN troubleshoot_bhome t
    ON t.ID_Customer = m.ID_Customer
    WHERE m.ID_Customer=%s AND m.Created_at >= CURDATE() - INTERVAL 7 DAY
    ORDER BY m.Created_at DESC
    LIMIT 50
    """, (id_customer,))
    rows = cursor.fetchall()

    return rows

"""
Entity : monitoring_all_modem
"""
def selectAllMonitoringAllModem(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute("""
    SELECT 
    ID_Noc,
    IP_Olt,
    Name,
    Type,
    Serial_Number,
    State,
    Redaman_Rx,
    DATE_FORMAT(Offline, '%%d-%%m-%%Y %%H:%%i:%%s') AS Offline,
    DATE_FORMAT(Authpass, '%%d-%%m-%%Y %%H:%%i:%%s') AS Authpass,
    DATE_FORMAT(Created_At, '%%d-%%m-%%Y %%H:%%i:%%s') AS Created_At
    FROM 
        monitoring_all_modem
    GROUP BY 
        ID_Noc 
    ORDER BY
        Created_At DESC
    LIMIT 50 ;
    """)
    rows = cursor.fetchall()

    return rows

def selectMonitoringAllModem(connection, search_term):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute("""
    SELECT 
    ID_Noc,
    IP_Olt,
    Name,
    Type,
    Serial_Number,
    State,
    Redaman_Rx,
    DATE_FORMAT(Offline, '%%d-%%m-%%Y %%H:%%i:%%s') AS Offline,
    DATE_FORMAT(Authpass, '%%d-%%m-%%Y %%H:%%i:%%s') AS Authpass,
    DATE_FORMAT(Created_At, '%%d-%%m-%%Y %%H:%%i:%%s') AS Created_At
    FROM 
        monitoring_all_modem
    WHERE 
        (CASE WHEN ID_Noc = %s THEN ID_Noc ELSE Serial_Number END) = %s AND
        Created_At >= NOW() - INTERVAL 7 DAY
    ORDER BY
        Created_At DESC
    LIMIT 50;
    """, (search_term, search_term))
    rows = cursor.fetchall()

    return rows
