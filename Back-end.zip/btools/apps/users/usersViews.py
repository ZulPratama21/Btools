from flask import Blueprint, render_template, flash, session, redirect, url_for, request
from btools.apps.users.usersQuery import *
from btools.apps.users.validateForm import *
from btools import limiter, login_user, User, current_user, generate_activation_link, send_activation_email

mod = Blueprint('users', __name__, url_prefix='/users')

@mod.route('/login', methods=['GET', 'POST'])
@limiter.limit("5/minute")
def index_login():
    connection = create_connection()
    if session.get("fullname"):
        next_page = request.args.get('next')
        return redirect(next_page or url_for('index_profile'))
    
    form = LoginForm()
    if form.validate_on_submit():
        get_username = form.username.data
        get_password = form.password.data
        
        if selectUser(connection, get_username) != None:
            if bcrypt.check_password_hash(selectUser(connection, get_username)['Password'], get_password):
                if selectUser(connection, get_username)['Active'] == 1:
                    user = User(selectUserAuth(create_connection(),user_id=selectUser(connection, get_username)['User_id'])[0], selectUserAuth(create_connection(), user_id=selectUser(connection, get_username)['User_id'])[1], selectUserAuth(create_connection(),user_id=selectUser(connection, get_username)['User_id'])[2], selectUserAuth(create_connection(),user_id=selectUser(connection, get_username)['User_id'])[3])
                    login_user(user)
                    session['fullname'] = selectUser(connection, get_username)['Name']
                    session['level'] = selectUser(connection, get_username)['Level']
                    next_page = request.args.get('next')
                    return redirect(next_page or url_for('index_profile'))
                flash('Akun anda belum aktif, silahkah hubungi tim NOC 📞', 'link')
            else:
                flash('Username atau password salah 😢', 'danger')
        else:
            flash('Username atau password salah 😢', 'danger')
    
    return render_template("users/login.html", form=form)

@mod.route('/register', methods=['GET', 'POST'])
@limiter.limit("3/minute")
def index_register():
    connection = create_connection()
    if session.get("username"):
        return "sudah login"
    
    form = RegisterForm()
    if form.validate_on_submit():
        get_name = form.name.data
        get_email = form.email.data
        get_username = form.username.data
        get_password = form.password.data
        
        if selectUser(connection, get_username) == None:
            activation_link = generate_activation_link(get_email)

            insertUser(connection, get_name, get_username, get_email, get_password, activation_link)
            flash('Akun berhasil dibuat 😍', 'primary')

            # Atasan 1 dan Atasan 2 (Ganti dengan email atasan Anda)
            atasans = ['juliandi@bnet.id']

            # Kirim email aktivasi ke dua atasan
            for atasan in atasans:
                send_activation_email(atasan, get_name, get_email, activation_link)

            return redirect(url_for('public.users.index_login'))
        else:
            flash('Akun sudah ada', 'danger')

    return render_template("users/register.html", form=form)

@mod.route('/logout', methods=['GET'])
def logout():
    session.clear()
    flash('Anda berhasil logout', 'info')
    return redirect(url_for('public.users.index_login'))