from btools import mysql as MYSQL
from btools import bcrypt
import pymysql


def create_connection():
    connection = None
    try:
        connection = MYSQL.connect()
    except Exception as e:
        print(e)
    return connection

def selectUserAuth(connection, user_id):
    cursor = connection.cursor()
    cursor.execute(
        f"SELECT User_id, Username, Password, Level FROM Users WHERE User_id='{user_id}'")
    rows = cursor.fetchone()

    return rows

def selectAllUsers(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM Users")
    rows = cursor.fetchall()

    return rows


def selectUser(connection, username):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        f"SELECT * FROM Users WHERE username='{username}'")
    rows = cursor.fetchone()

    return rows


def insertUser(connection, name, username, email, password, token):
    hash_password = bcrypt.generate_password_hash(password=password).decode('utf-8')
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(f"""
    INSERT INTO Users (`Name`, `Username`, `Email`, `Password`, `Token`) VALUES ('{name}', '{username}', '{email}', '{hash_password}', '{token}');;
    """)
    connection.commit()

    return None

