from flask import Blueprint, jsonify, request
from flask import jsonify
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from btools import limiter, role_required

mod = Blueprint('installation', __name__, url_prefix='/installation')


@mod.route('/bhome/1/execute', methods=['GET', 'POST'])
@role_required(['Master', 'NOC'])
def installation_bhome_1():
    # Get Parameter From URL
    get_serial_number = request.args.get(
        'serial_number', default=None, type=str)
    get_id_noc = request.args.get('id_noc', default=None, type=int)
    get_ip_address = request.args.get('ip_address', default=None, type=str)
    get_subnetmask = request.args.get('subnetmask', default=None, type=str)
    get_limitation = request.args.get('limitation', default=None, type=str)
    get_type_modem = request.args.get('type_modem', default=None, type=str)

    if get_serial_number and get_id_noc and get_ip_address and get_subnetmask and get_limitation and (get_limitation == "Gaming-10M" or get_limitation == "Gaming-20M" or get_limitation == "Gaming-50M" or get_limitation == "Gaming-75M"):
        # Slicing Get ID NOC
        get_id_noc = str(get_id_noc)
        id_noc_to_port = int(get_id_noc[1:3])
        id_noc_to_onuIndex = int(get_id_noc[3:5])
        id_noc_to_vlan = int(get_id_noc[0:3])
        interface_modul = 1

        # Remove 0 if port is less than 10
        if id_noc_to_port >= 67:
            id_noc_to_port -= 66
            interface_modul = 2
        elif id_noc_to_port >= 51:
            id_noc_to_port -= 50
        elif id_noc_to_port > 16:
            id_noc_to_port -= 16
            interface_modul = 2
        elif id_noc_to_port < 10:
            id_noc_to_port = str(id_noc_to_port).replace("0", "")

        # Remove 0 if onu index is less than 10
        if id_noc_to_onuIndex < 10:
            id_noc_to_onuIndex = str(id_noc_to_onuIndex).replace("0", "")

        return jsonify(
            {
                "code": 200,
                "status": "OK",
                "data": {
                    "prompt": f"""
interface gpon-olt_1/{interface_modul}/{id_noc_to_port}
onu {id_noc_to_onuIndex} type {get_type_modem} sn {get_serial_number}
exit
interface gpon-onu_1/{interface_modul}/{id_noc_to_port}:{id_noc_to_onuIndex}
sn-bind enable sn
tcont 1 name ip{id_noc_to_vlan} profile {get_limitation}
gemport 1 name ip{id_noc_to_vlan} tcont 1
gemport 1 traffic-limit upstream U-{get_limitation} downstream D-{get_limitation}
service-port 1 vport 1 user-vlan {id_noc_to_vlan} vlan {id_noc_to_vlan}
exit
pon-onu-mng gpon-onu_1/{interface_modul}/{id_noc_to_port}:{id_noc_to_onuIndex}
firewall enable level low
service ip{id_noc_to_vlan} gemport 1 vlan {id_noc_to_vlan}
wan-ip 1 mode static ip-profile ip{id_noc_to_vlan} ip-address {get_ip_address} mask {get_subnetmask} vlan-profile vlan{id_noc_to_vlan} host 1
vlan port eth_0/1 mode tag vlan {id_noc_to_vlan}
security-mgmt 1 state enable mode forward protocol web
exit"""
                }
            }
        ), 200

    return jsonify(
        {
            "code": 400,
            "status": "BAD_REQUEST",
            "errors": {
                "serial_number": [
                    "required parameters",
                    "no whitespace"
                ],
                "id_noc": [
                    "required parameters",
                    "no whitespace",
                    "maximum must be 5 digits",
                    "only integer"
                ],
                "ip_address": [
                    "required parameters",
                    "no whitespace",
                    "ip address format should be like 192.168.100.1"
                ],
                "subnetmask": [
                    "required parameters",
                    "no whitespace",
                    "a subnet mask like 255.255.255.0 instead of a prefix like /24"
                ],
                "limitation": [
                    "required parameters",
                    "no whitespace",
                    "writing limitations such as Gaming-10M, Gaming-20M, Gaming-50M and Gaming-75M"
                ]
            }
        }
    ), 400


@mod.route('/bhome/2/execute', methods=['GET', 'POST'])
@role_required(['Master', 'NOC'])
def installation_bhome_2():
    # Get Parameter From URL
    get_serial_number = request.args.get(
        'serial_number', default=None, type=str)
    get_id_noc = request.args.get('id_noc', default=None, type=int)
    get_limitation = request.args.get('limitation', default=None, type=str)
    get_type_modem = request.args.get('type_modem', default=None, type=str)

    if get_serial_number and get_id_noc and get_limitation and (get_limitation == "Gaming-10M" or get_limitation == "Gaming-20M" or get_limitation == "Gaming-50M" or get_limitation == "Gaming-75M"):
        # Slicing Get ID NOC
        get_id_noc = str(get_id_noc)
        id_noc_to_port = int(get_id_noc[1:3])
        id_noc_to_onuIndex = int(get_id_noc[3:5])
        id_noc_to_vlan = int(get_id_noc[0:3])
        interface_modul = 1

        # Remove 0 if port is less than 10
        if id_noc_to_port >= 67:
            id_noc_to_port -= 66
            interface_modul = 2
        elif id_noc_to_port >= 51:
            id_noc_to_port -= 50
        elif id_noc_to_port > 16:
            id_noc_to_port -= 16
            interface_modul = 2
        elif id_noc_to_port < 10:
            id_noc_to_port = str(id_noc_to_port).replace("0", "")

        # Remove 0 if onu index is less than 10
        if id_noc_to_onuIndex < 10:
            id_noc_to_onuIndex = str(id_noc_to_onuIndex).replace("0", "")

        if get_type_modem == "ZTE-F660":
            return jsonify(
                {
                    "code": 200,
                    "status": "OK",
                    "data": {
                        "prompt": f"""
interface gpon-olt_1/{interface_modul}/{id_noc_to_port}
onu {id_noc_to_onuIndex} type ZTE-F660 sn {get_serial_number}
exit
interface gpon-onu_1/{interface_modul}/{id_noc_to_port}:{id_noc_to_onuIndex}
sn-bind enable sn
tcont 1 name pppoenat profile {get_limitation}
gemport 1 name pppoenat tcont 1
gemport 1 traffic-limit upstream U-{get_limitation} downstream D-{get_limitation}
service-port 1 vport 1 user-vlan {id_noc_to_vlan} vlan {id_noc_to_vlan}
exit
pon-onu-mng gpon-onu_1/{interface_modul}/{id_noc_to_port}:{id_noc_to_onuIndex}
firewall enable level low
service pppoenat gemport 1 iphost 1 vlan {id_noc_to_vlan}
pppoe 1 nat enable user {get_id_noc}@bnethome password bnet{get_id_noc}
security-mgmt 1 state enable mode forward protocol web
exit"""
                    }
                }
            ), 200
        elif get_type_modem == "OPEN_HGW":
            return jsonify(
                {
                    "code": 200,
                    "status": "OK",
                    "data": {
                        "prompt": f"""
interface gpon-olt_1/{interface_modul}/{id_noc_to_port}
onu {id_noc_to_onuIndex} type OPEN_HGW sn {get_serial_number}
exit
interface gpon-onu_1/{interface_modul}/{id_noc_to_port}:{id_noc_to_onuIndex}
sn-bind enable sn
tcont 1 name pppoenat profile {get_limitation}
gemport 1 name pppoenat tcont 1
gemport 1 traffic-limit upstream U-{get_limitation} downstream D-{get_limitation}
service-port 1 vport 1 user-vlan {id_noc_to_vlan} vlan {id_noc_to_vlan}
exit
pon-onu-mng gpon-onu_1/{interface_modul}/{id_noc_to_port}:{id_noc_to_onuIndex}
firewall enable level low
service pppoenat gemport 1 iphost 1 vlan {id_noc_to_vlan}
wan-ip 1 mode pppoe username {get_id_noc}@bnethome password bnet{get_id_noc} vlan-profile vlan{id_noc_to_vlan} host 1
wan-ip 1 ping-response enable traceroute-response enable
security-mgmt 1 state enable mode forward protocol web
wan 1 ethuni 1 ssid 1 service tr069 internet host 1
exit"""
                    }
                }
            ), 200

    return jsonify(
        {
            "code": 400,
            "status": "BAD_REQUEST",
            "errors": {
                "serial_number": [
                    "required parameters",
                    "no whitespace"
                ],
                "id_noc": [
                    "required parameters",
                    "no whitespace",
                    "maximum must be 5 digits",
                    "only integer"
                ],
                "ip_address": [
                    "required parameters",
                    "no whitespace",
                    "ip address format should be like 192.168.100.1"
                ],
                "subnetmask": [
                    "required parameters",
                    "no whitespace",
                    "a subnet mask like 255.255.255.0 instead of a prefix like /24"
                ],
                "limitation": [
                    "required parameters",
                    "no whitespace",
                    "writing limitations such as Gaming-10M, Gaming-20M, Gaming-50M and Gaming-75M"
                ]
            }
        }
    ), 400

@mod.route('/bcorp/1/execute', methods=['GET', 'POST'])
@role_required(['Master', 'NOC'])
def installation_bcorp_1():
    # Get Parameter From URL
    get_type_modem = request.args.get('type_modem', default=None, type=str)
    get_interface_router = request.args.get('interface_router', type=str)
    get_ip_address_end_device = request.args.get('ip_address', type=str)
    get_prefix = request.args.get('prefix', type=str)
    get_serial_number = request.args.get('serial_number', type=str)
    get_id_noc = request.args.get('id_noc', type=int)
    get_profile_1 = request.args.get('profile_1', type=str)
    get_profile_2 = request.args.get('profile_2', default=None, type=str)
    get_name_profile = request.args.get('name_profile', default=None, type=str)
    get_bridge = request.args.get('bridge', type=str)
    get_double_package = request.args.get('double_package', type=str)

    # Slicing Get ID NOC
    get_id_noc = str(get_id_noc)
    id_noc_to_port = int(get_id_noc[1:3])
    id_noc_to_onuIndex = int(get_id_noc[3:5])
    id_noc_to_vlan = int(get_id_noc[0:3])
    interface_modul = 1

    # Remove 0 if port is less than 10
    if id_noc_to_port >= 67:
        id_noc_to_port -= 66
        interface_modul = 2
    elif id_noc_to_port >= 51:
        id_noc_to_port -= 50
    elif id_noc_to_port > 16:
        id_noc_to_port -= 16
        interface_modul = 2
    elif id_noc_to_port < 10:
        id_noc_to_port = str(id_noc_to_port).replace("0", "")
        
    # Remove 0 if onu index is less than 10
    if id_noc_to_onuIndex < 10:
        id_noc_to_onuIndex = str(id_noc_to_onuIndex).replace("0", "")

    # Selection Vlan Number
    if get_interface_router == 'vlan1901-olt1':
        vlan = 1901
    elif get_interface_router == 'vlan1902-olt2':
        vlan = 1902
    elif get_interface_router == 'vlan1903-olt3':
        vlan = 1903
    elif get_interface_router == 'vlan1904-olt4':
        vlan = 1904
    elif get_interface_router == 'vlan1905-olt1':
        vlan = 1905
    elif get_interface_router == 'vlan1906-olt6':
        vlan = 1906
    elif get_interface_router == 'vlan1801-olt5':
        vlan = 1801

    #IP Calculator
    url_network_calc = requests.get(f"http://networkcalc.com/api/ip/{get_ip_address_end_device}/{get_prefix}",verify=False).json()
    ip_address_gateway = url_network_calc['address']['first_assignable_host']
    subnetmask = url_network_calc['address']['subnet_mask']

    if get_double_package == "false" and get_bridge == "false":
        output = f"""
gpon <br>
onu profile ip {get_name_profile} gateway {ip_address_gateway} primary-dns 103.73.73.71 second-dns 103.73.73.72 <br>
exit <br>
interface gpon-olt_1/{interface_modul}/{id_noc_to_port} <br>
onu {id_noc_to_onuIndex} type {get_type_modem} sn {get_serial_number} <br>
exit <br>
interface gpon-onu_1/{interface_modul}/{id_noc_to_port}:{id_noc_to_onuIndex} <br>
sn-bind enable sn <br>
tcont 1 name ip{vlan} profile {get_profile_1} <br>
gemport 1 name ip{vlan} tcont 1 <br>
service-port 1 vport 1 user-vlan {vlan} vlan {vlan} <br>
exit <br>
pon-onu-mng gpon-onu_1/{interface_modul}/{id_noc_to_port}:{id_noc_to_onuIndex} <br>
firewall enable level low <br>
service ip{vlan} gemport 1 vlan {vlan} <br>
wan-ip 1 mode static ip-profile {get_name_profile} ip-address {get_ip_address_end_device} mask {subnetmask} vlan-profile vlan{vlan} host 1 <br>
security-mgmt 1 state enable mode forward protocol web <br>
exit
"""
    elif get_double_package == "false" and get_bridge == "true":
        output = f"""
interface gpon-olt_1/{interface_modul}/{id_noc_to_port} <br>
onu {id_noc_to_onuIndex} type {get_type_modem} sn {get_serial_number} <br>
exit <br>
interface gpon-onu_1/{interface_modul}/{id_noc_to_port}:{id_noc_to_onuIndex} <br>
sn-bind enable sn <br>
tcont 1 name ip{vlan} profile {get_profile_1} <br>
gemport 1 name ip{vlan} tcont 1 <br>
service-port 1 vport 1 user-vlan {vlan} vlan {vlan} <br>
exit <br>
pon-onu-mng gpon-onu_1/{interface_modul}/{id_noc_to_port}:{id_noc_to_onuIndex} <br>
firewall enable level low <br>
service ip{vlan} gemport 1 vlan {vlan} <br>
wan-ip 1 mode static ip-profile ip{vlan} ip-address {get_ip_address_end_device} mask {subnetmask} vlan-profile vlan{vlan} host 1 <br>
vlan port eth_0/1 mode tag vlan {vlan} <br>
security-mgmt 1 state enable mode forward protocol web <br>
exit
"""
    elif get_double_package == "true" and get_bridge == "true":
            output = f"""
interface gpon-olt_1/{interface_modul}/{id_noc_to_port} <br>
onu {id_noc_to_onuIndex} type {get_type_modem} sn {get_serial_number} <br>
exit <br>
interface gpon-onu_1/{interface_modul}/{id_noc_to_port}:{id_noc_to_onuIndex} <br>
sn-bind enable sn <br>
tcont 1 name ip{vlan} profile {get_profile_1} <br>
tcont 2 name ip{id_noc_to_vlan} profile {get_profile_2} <br>
gemport 1 name ip{vlan} tcont 1 <br>
gemport 2 name ip{id_noc_to_vlan} tcont 2 <br>
service-port 1 vport 1 user-vlan {vlan} vlan {vlan} <br>
service-port 2 vport 2 user-vlan {id_noc_to_vlan} vlan {id_noc_to_vlan} <br>
exit <br>
pon-onu-mng gpon-onu_1/{interface_modul}/{id_noc_to_port}:{id_noc_to_onuIndex} <br>
service ip{vlan} gemport 1 vlan {vlan} <br>
service ip{id_noc_to_vlan} gemport 2 vlan {id_noc_to_vlan} <br>
wan-ip 1 mode static ip-profile ip{vlan} ip-address {get_ip_address_end_device} mask {subnetmask} vlan-profile vlan{vlan} host 1 <br>
vlan port eth_0/1 mode tag vlan {vlan} <br>
vlan port eth_0/2 mode tag vlan {id_noc_to_vlan} <br>
security-mgmt 1 state enable mode forward protocol web <br>
exit
"""
    else:
        return jsonify(
        {
            "code": 400,
            "status": "BAD_REQUEST",
            "errors": {
                "serial_number": [
                    "required parameters",
                    "no whitespace"
                ],
                "id_noc": [
                    "required parameters",
                    "no whitespace",
                    "maximum must be 5 digits",
                    "only integer"
                ],
                "ip_address": [
                    "required parameters",
                    "no whitespace",
                    "ip address format should be like 192.168.100.1"
                ],
                "subnetmask": [
                    "required parameters",
                    "no whitespace",
                    "a subnet mask like 255.255.255.0 instead of a prefix like /24"
                ],
                "limitation": [
                    "required parameters",
                    "no whitespace",
                    "writing limitations such as Gaming-10M, Gaming-20M, Gaming-50M and Gaming-75M"
                ]
            }
        }
    ), 400
    return jsonify(
        {
            "code": 200,
            "status": "OK",
            "data": {
                "prompt": output
            }
        }
    ), 200
