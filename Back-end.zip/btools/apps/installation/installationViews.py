from flask import Blueprint, render_template
from btools import role_required

mod = Blueprint('installation', __name__, url_prefix='/installation')

@mod.route('/bhome/1/', methods=['GET'])
@role_required(['Master', 'NOC'])
def index_bhome_1():
    return render_template('installation/Installation_Bhome1.html')

@mod.route('/bhome/2/', methods=['GET'])
@role_required(['Master', 'NOC'])
def index_bhome_2():
    return render_template('installation/Installation_Bhome2.html')

@mod.route('/bcorp/fo/', methods=['GET'])
@role_required(['Master', 'NOC'])
def index_bcorp_fiber_optic():
    return render_template('installation/Installation_Bcorp_fiber_optic.html')

@mod.route('/bcorp/wireless/', methods=['GET'])
@role_required(['Master', 'NOC'])
def index_bcorp_wireless():
    return render_template('installation/Installation_Bcorp_wireless.html')

