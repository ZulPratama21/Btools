from flask import Blueprint, render_template, request, redirect, flash, abort, session, url_for
from btools.apps.dashboard.dashboardQuery import *
from btools import role_required

mod = Blueprint('dashboard', __name__, url_prefix='/dashboard')
    
@mod.route('/', methods=['GET', 'POST'])
@role_required(['Master'])
def index_dashboard():
    
    connection = create_connection()
    countUsersBtools = len (selectAllUsers(connection))
    countUsersBhome = len(selectAllBhome(connection))
    countUsersBcorp = len(selectAllBcorp(connection))

    countParentRouter = len(selectAllParent(connection))
    countAccessPoint = len(selectAllRadio(connection))
    countOlt = len(selectAllOlt(connection))

    countRestrictedAccessPoint = selectCountRestrictedAccessPoint(connection)[0]['countRestrictedFrequency']
    countHighSignalRadioStation = selectCountHighSignalRadioStation(connection)[0]['countHighSignal']
    connection.close()

    return render_template("users/master/dashboard.html", 
                            countUsersBtools=countUsersBtools, countUsersBhome=countUsersBhome, countUsersBcorp=countUsersBcorp, 
                            countParentRouter=countParentRouter, countAccessPoint=countAccessPoint, countOlt=countOlt, countRestrictedAccessPoint=countRestrictedAccessPoint,
                            countHighSignalRadioStation=countHighSignalRadioStation
                            )

@mod.route('/users', methods=['GET', 'POST'])
@role_required(['Master'])
def index_users():
    connection = create_connection()
    showAllUsers = selectAllUsers(connection)

    if request.method == 'POST':
        user_id = request.form['user_id']
        name = request.form['name']
        username = request.form['username']
        active = request.form['status']
        level = request.form['level']
        updateUser(connection, user_id, name=name, username=username, active=active, level=level)
        return redirect(url_for('private.dashboard.index_users'))
    return render_template("users/master/users.html", showAllUsers=showAllUsers)