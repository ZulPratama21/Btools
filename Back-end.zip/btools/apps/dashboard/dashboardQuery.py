from btools import mysql as MYSQL
import pymysql


def create_connection():
    connection = None
    try:
        connection = MYSQL.connect()
    except Exception as e:
        print(e)
    return connection

"""
Entity : troubleshoot_parent
"""
def selectAllParent(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM `troubleshoot_parent`")
    rows = cursor.fetchall()

    return rows

"""
Entity : troubleshoot_olt
"""
def selectAllOlt(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT * FROM `troubleshoot_olt`")
    rows = cursor.fetchall()

    return rows

"""
Entity : troubleshoot_bhome
"""
def selectAllBhome(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        f"SELECT * FROM troubleshoot_bhome")
    rows = cursor.fetchall()

    return rows

"""
Entity : troubleshoot_bcorp
"""
def selectAllBcorp(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        f"SELECT * FROM troubleshoot_bcorp")
    rows = cursor.fetchall()

    return rows

"""
Entity : monitoringradio_radio
"""
def selectAllRadio(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(
        f"SELECT * FROM monitoringradio_radio")
    rows = cursor.fetchall()

    return rows

def selectCountRestrictedAccessPoint(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT COUNT(Restricted_Frequency) AS countRestrictedFrequency FROM monitoringradio_accesspoint WHERE Restricted_Frequency=1")
    rows = cursor.fetchall()

    return rows

def selectCountCCQLowRadioStation(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT COUNT(ID_Radio) as countLowCCQ FROM monitoringradio_station WHERE CCQTx <=50 AND CCQRx <=50 AND DATE_FORMAT(monitoringradio_station.Created_at, '%Y-%m-%d') >= DATE_SUB(DATE(NOW()), INTERVAL 1 DAY)")
    rows = cursor.fetchall()

    return rows

def selectCountHighSignalRadioStation(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute("SELECT COUNT(ID_Station_Name) AS countHighSignal FROM monitoringradio_station WHERE SignalTx<-65 and SignalRx <-65 AND DATE_FORMAT(monitoringradio_station.Created_at, '%Y-%m-%d')  >= DATE_SUB(DATE(NOW()), INTERVAL 1 DAY)")
    rows = cursor.fetchall()

    return rows

"""
Entity : Users
"""
def selectAllUsers(connection):
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM Users")
    rows = cursor.fetchall()

    return rows

def updateUser(connection, userId, name, username, active, level):
    cursor = connection.cursor()
    cursor.execute(f"UPDATE Users SET name= '{name}', username='{username}', active='{active}', Level='{level}' WHERE User_id={userId};")
    connection.commit()

    return None