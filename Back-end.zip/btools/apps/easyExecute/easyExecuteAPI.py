import routeros_api
import time
import paramiko
from flask import Blueprint, jsonify, request
from flask import jsonify
from btools import limiter, role_required
from btools.apps.troubleshoot.troubleshootQuery import *

mod = Blueprint('easyexecute', __name__, url_prefix='/easyexecute')


@mod.route('/olt', methods=['GET', 'POST'])
@role_required(['Master', 'NOC'])
@limiter.limit("1/30 second")
def easyexecute_olt():
    get_command = request.args.get('command', type=str)
    get_id_olt = request.args.get('id_olt', default=None, type=str)

    def remote_olt():
        if get_id_olt == "OLT1":
            ip_olt = "172.16.1.106"
        elif get_id_olt == "OLT2":
            ip_olt = "172.16.1.110"
        elif get_id_olt == "OLT3":
            ip_olt = "172.16.1.114"
        elif get_id_olt == "OLT4":
            ip_olt = "172.16.1.118"
        elif get_id_olt == "OLT5":
            ip_olt = "172.16.1.122"
        elif get_id_olt == "OLT6":
            ip_olt = "172.16.1.126"
        try:
            conn = paramiko.SSHClient()
            conn.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            conn.connect(ip_olt, 22, "netb", "NetBpastimaju123")

            commands = conn.invoke_shell()
            commands.send("terminal length 0\n")
            time.sleep(1)
            commands.send(get_command + "\n")
            time.sleep(1)
            output = commands.recv(65535).decode("utf-8")

            return jsonify(
                {
                    "code": 200,
                    "status": "OK",
                    "data": {
                        "prompt": output
                    }
                }
            ), 200
        except:
            return jsonify(
                {
                    "code": 503,
                    "status": "SERVER_ERROR",
                    "errors": {
                        "please contact related team!"
                    }
                }
            ), 503

    if get_command and get_id_olt:
        return remote_olt()

    return jsonify(
        {
            "code": 400,
            "status": "BAD_REQUEST",
            "errors": {
                "command": [
                    "required parameters",
                    "required encode value"
                ],
                "id_noc": [
                    "required parameters",
                    "only OLT1, OLT2, OLT3 & OLT4"
                ]
            }
        }
    ), 400


@mod.route('/mikrotik', methods=['GET', 'POST'])
@role_required(['Master', 'NOC'])
@limiter.limit("133/30 second")
def easyexecute_mikrotik():
    get_action = request.args.get('action', type=str)
    get_authentication = request.args.get('authentication', default=None, type=str)
    get_id_customer = request.args.get('id_customer', default=None, type=str)

    # Change DNS Backup to DNS Main
    if get_action == 'change_link_main' and get_authentication == 'Bnetcore137':
        connection = routeros_api.RouterOsApiPool("103.73.72.6", username='btools', password='netbtools23', plaintext_login=True)
        api = connection.get_api()

        list_firewall_nat = api.get_resource('ip/firewall/nat')


        #Disable DNS Backup TCP
        list_firewall_nat.set(id="*9", disabled="true")
        #Disable DNS Backup UDP
        list_firewall_nat.set(id="*A", disabled="true")

        #Enable DNS Main TCP
        list_firewall_nat.set(id="*B", disabled="false")
        #Enable DNS Main UDP
        list_firewall_nat.set(id="*C", disabled="false")

        return jsonify(
            {
                "code": 200,
                "status": "OK",
                "data": {
                    "output": list_firewall_nat.get()
                }
            }
        ), 200

    elif get_action == 'change_link_backup' and get_authentication == 'Bnetcore137':
        connection = routeros_api.RouterOsApiPool("103.73.72.6", username='btools', password='netbtools23', plaintext_login=True)
        api = connection.get_api()

        list_firewall_nat = api.get_resource('ip/firewall/nat')

        #Enable DNS Backup TCP
        list_firewall_nat.set(id="*9", disabled="false")
        #Enable DNS Backup UDP
        list_firewall_nat.set(id="*A", disabled="false")

        #Disable DNS Main TCP
        list_firewall_nat.set(id="*B", disabled="true")
        #Disable DNS Main UDP
        list_firewall_nat.set(id="*C", disabled="true")

        return jsonify(
            {
                "code": 200,
                "status": "OK",
                "data": {
                    "output": "Change DNS Main to DNS Backup Success"
                }
            }
        ), 200

    elif get_action == 'check_blocked_users'and  get_id_customer !=None:

        data = selectTroubleshhotBhomeJoinTroubleshootParent(create_connection(), get_id_customer)
        if data != None:
            ip_parent = data['ip_parent']
            username_parent = data['username_parent']
            password_parent = data['password_parent']
            remote_address = data['ip_client']

            connection = routeros_api.RouterOsApiPool(ip_parent, username=username_parent, password=password_parent, plaintext_login=True)
            api = connection.get_api()
            
            list_address_list_details = api.get_resource('ip/firewall/address-list').get(address=remote_address)
            list_address_list_allow = api.get_resource('ip/firewall/address-list').get(address=remote_address, list="allow")
            status_client = "allow" if len(list_address_list_allow) != 0 else 'blocked'
            
            return jsonify(
                {
                    "code": 200,
                    "status": "OK",
                    "data": {
                        "output": status_client,
                        "details" : list_address_list_details
                    }
                }
            ), 200

    return jsonify(
        {
            "code": 400,
            "status": "BAD_REQUEST",
            "errors": {
                "action": [
                    "required parameters action"
                ],
                "authentication": [
                    "not valid authentication",
                ]
            }
        }
    ), 400
