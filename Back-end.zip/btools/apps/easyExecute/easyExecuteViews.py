from flask import Blueprint, render_template
from btools import role_required

mod = Blueprint('easyexecute', __name__, url_prefix='/easyexecute')

@mod.route('/olt', methods=['GET'])
@role_required(['Master', 'NOC'])
def index_olt():
    return render_template('easyExecute/OpticalLineTermination.html')

@mod.route('/mikrotik', methods=['GET'])
@role_required(['Master', 'NOC'])
def index_mikrotik():
    return render_template('easyExecute/Mikrotik.html')

@mod.route('/link_budget', methods=['GET'])
@role_required(['Master', 'NOC', 'Technical'])
def index_link_budget_calculator():
    return render_template('easyExecute/LinkBudgetCalculator.html')

