from flask import Blueprint
mod_api = Blueprint('api', __name__, url_prefix='/api/v1')
mod_socket = Blueprint('socket', __name__, url_prefix='/socket/v1')
mod_public = Blueprint('public', __name__, url_prefix='/public')
mod_private = Blueprint('private', __name__, url_prefix='/private')
