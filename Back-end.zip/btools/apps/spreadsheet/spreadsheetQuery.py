from btools import mysql as MYSQL
import pymysql


def create_connection():
    connection = None
    try:
        connection = MYSQL.connect()
    except Exception as e:
        print(e)
    return connection


"""
Entity : spreadsheet_odp
"""


def selectSpreadsheetOdp(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute(""" 
        SELECT id, port_remaining, coordinate, alamat, port_olt, DATE_FORMAT(update_time, '%Y-%m-%d %H:%i:%s') as update_time
        FROM spreadsheet_odp
        ORDER BY update_time DESC;
    """)
    rows = cursor.fetchall()

    return rows
