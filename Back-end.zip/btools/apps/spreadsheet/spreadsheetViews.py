from flask import Blueprint, render_template
from btools import role_required

mod = Blueprint('spreadsheet', __name__, url_prefix='/spreadsheet')

@mod.route('/odp', methods=['GET'])
@role_required(['Master', 'NOC', 'Technical'])
def index_data_odp():
    return render_template("spreadsheet/data_odp.html")