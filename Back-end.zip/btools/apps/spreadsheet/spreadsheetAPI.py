from flask import Blueprint, jsonify, request
from flask import jsonify
from btools import limiter, role_required
from btools.apps.spreadsheet.spreadsheetQuery import *

mod = Blueprint('spreadsheet', __name__, url_prefix='/spreadsheet')

"""
Menu : Spreadsheet Data ODP
"""
@mod.route('/odp', methods=['GET'])
@role_required(['Master', 'NOC', 'Technical'])
def spreadsheet_odp():
    connection = create_connection()
    all_data = selectSpreadsheetOdp(connection)

    respon = jsonify(
        {
            "code": 200,
            "status": "OK",
            "data": all_data,
            "page": {
                "size": len(all_data),
                "total": 100,
                "totalPages": 5,
                "current": 1
            }
        }
    ), 200
    return respon