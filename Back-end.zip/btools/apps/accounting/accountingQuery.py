from btools import mysql as MYSQL
import pymysql


def create_connection():
    connection = None
    try:
        connection = MYSQL.connect()
    except Exception as e:
        print(e)
    return connection


def selectAllDataSuspend(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute("""
    SELECT * FROM spreadsheet_suspend
    """)
    rows = cursor.fetchall()

    return rows

def selectAllDataSuspendExport(connection):
    cursor = connection.cursor()
    cursor.execute("""
    SELECT
    ID_Customer,
    Name,
    Suspend_By_Router,
    CASE
        WHEN Status_internet = 1 THEN 'Active'
        WHEN Status_internet = 0 THEN 'Suspended'
    END AS Status_internet,
    Update_at
    FROM
    spreadsheet_suspend;

    """)
    rows = cursor.fetchall()

    return rows

def selectLastUpdate(connection):
    cursor = connection.cursor(pymysql.cursors.DictCursor)
    cursor.execute("""
    SELECT DATE_FORMAT(Update_at, '%d-%b-%Y %H:%i:%s') as Update_at  FROM spreadsheet_suspend LIMIT 1  
    """)
    rows = cursor.fetchall()

    return rows