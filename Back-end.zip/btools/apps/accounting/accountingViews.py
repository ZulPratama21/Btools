from flask import Blueprint, render_template, request, redirect, flash
from btools import role_required
from btools.apps.troubleshoot.troubleshootQuery import create_connection, selectBhome

mod = Blueprint('accounting', __name__, url_prefix='/accounting')

@mod.route('/suspend', methods=['GET'])
@role_required(['Master', 'NOC', 'Finance'])
def index_suspend():
    return render_template("accounting/DataSuspend.html")