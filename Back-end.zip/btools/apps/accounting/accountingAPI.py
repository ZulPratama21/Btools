from flask import Blueprint, jsonify, request, Response
from flask import jsonify
from btools import limiter, role_required, openpyxl, BytesIO, datetime
from btools.apps.accounting.accountingQuery import *

mod = Blueprint('accounting', __name__, url_prefix='/accounting')

"""
Menu : Data Suspend
"""

@mod.route('/suspend/', methods=['GET'])
@role_required(['Master', 'NOC', 'Finance'])
def data_suspend():
    connection = create_connection()
    all_data = selectAllDataSuspend(connection)
    last_update = selectLastUpdate(connection)
    respon = jsonify(
        {
            "code": 200,
            "status": "OK",
            "data": all_data,
            "last_update": last_update[0]['Update_at'],
            "page": {
                "size": len(all_data),
                "total": 100,
                "totalPages": 5,
                "current": 1
            }
        }
    ), 200
    return respon

@mod.route('/suspend/export', methods=['GET'])
@role_required(['Master', 'NOC', 'Finance'])
def data_suspend_export():
    connection = create_connection()
    all_data = selectAllDataSuspendExport(connection)

    wb = openpyxl.Workbook()
    ws = wb.active

    ws.append(["ID_Customer", "Name", "Suspend_By_Router", "Status_internet", "Update_at"])
    
    for row in all_data:
        ws.append(row)
    
    output = BytesIO()
    wb.save(output)
    output.seek(0)

    now = datetime.datetime.now()
    date_string = now.strftime("%Y-%m-%d")
    
    filename = f"Checker_Status_Customer-{date_string}.xlsx"
    
    response = Response(output.read(), content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    response.headers["Content-Disposition"] = f"attachment; filename={filename}"
    return response