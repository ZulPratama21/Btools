import pandas as pd, time
from spreadsheet.query import *
df = pd.read_csv('https://docs.google.com/spreadsheets/d/1f6FhfpTWDLCpkBdrbA2tfMCDDNmUroUC7rLXe5F5F1I/export?format=csv&gid=1557606187', delimiter=',', header=1)

def run():
    # Daftar kolom yang ingin di-loop
    columns = ['Non_Residensial', 'Grahayana', 'Bumi_Taruno', 'Karang_Indah', 'Mall_KCP', 'Karawang_Indah']

    for column in columns:
        id_odp = df[f'ID ODP_{column}'].dropna().to_list()
        port_remaining = df[f'Port Remaining_{column}'].fillna(0).to_list()
        titik_kordinate = df[f'TITIK KORDINAT_{column}'].fillna(0).to_list()
        alamat = df[f'Alamat_{column}'].fillna(0).to_list()
        port_olt = df[f'Port OLT_{column}'].fillna(0).to_list()

        for i in range(len(id_odp)):
            insertSpreadsheetODP(id_odp[i], port_remaining[i], titik_kordinate[i], alamat[i], port_olt[i])