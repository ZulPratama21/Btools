import pymysql, datetime
from database.connection import create_conntection

current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def insertSpreadsheetODP(id_odp, port_remaining, coordinate, alamat, port_olt):
    try:
        conn = create_conntection()
        cursor = conn.cursor()
        cursor.execute(f"""INSERT INTO spreadsheet_odp (id, port_remaining, coordinate, alamat, port_olt, update_time) VALUES ('{id_odp}', {port_remaining}, '{coordinate}', '{alamat}', '{port_olt}', '{current_time}');""")
        conn.commit()
        conn.close()
        print("Data inserted successfully!")
    except Exception as err:
        print(err)
        conn.close()
        updateSpreadsheetODP(id_odp, port_remaining, coordinate, alamat, port_olt)

    return None

def updateSpreadsheetODP(id_odp, port_remaining, coordinate, alamat, port_olt):
    try:
        conn = create_conntection()
        cursor = conn.cursor()

        # Cek apakah ada perubahan data sebelum melakukan update
        cursor.execute(f"SELECT port_remaining, coordinate, port_olt FROM spreadsheet_odp WHERE id = '{id_odp}';")
        current_data = cursor.fetchone()
        if current_data is not None and current_data != (port_remaining, coordinate, alamat, port_olt):
            cursor.execute(f"""UPDATE spreadsheet_odp SET port_remaining = {port_remaining}, coordinate = '{coordinate}', alamat = '{alamat}', port_olt = '{port_olt}', update_time = '{current_time}' WHERE id = '{id_odp}';""")
            conn.commit()
            print("Data updated successfully!")
        else:
            print("No changes in data, update not required.")
        conn.close()

    except Exception as err:
        conn.close()
        print("Error updating data:", err)

    return None