#. /home/bnet/Project/BTools/.env/bin/activate
cd /home/bnet/Project/BTools/Back-End/btools/automation
python3 __init__.py checking_all_modem
