import json
import routeros_api
import csv
import datetime
import time
import os
from periodic_checking.logger import capture_log
from periodic_checking.query import *

config_authentication = json.load(open(os.path.join(
    os.path.dirname(__file__)) + '/configuration/authentication.json'))
config_linkSfp = json.load(open(os.path.join(
    os.path.dirname(__file__)) + '/configuration/link_sfp.json'))


def run():
    capture_log.logging.info(f"======LINK SFP======")
    # Header .csv
    header = ['no', 'source', 'interface', 'comment_or_CID', 'receive',
              'transmite', 'state', 'last_link_up', 'link_down', 'message', 'time']

    # Tampung Data
    data = []

    list_autentikasi = config_authentication['autentikasi']
    list_device = config_linkSfp['link_sfp']['device']

    for i in range(len(list_device)):
        # Default Value
        device_identity = ""
        interface_name = ""
        interface_comment = ""
        result_receive = 0
        result_transmite = 0
        interface_status = ""
        interface_up_time = ""
        interface_down = 0

        count = i + 1
        timestamp = str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M"))
        device_identity = list_device[i]['identity']
        device_ip = list_device[i]['ip']
        list_device_interface = list_device[i]['interface']
        device_autentikasi = list_device[i]['autentikasi']
        device_vendor = list_device[i]['vendor']

        device_username = str(list_autentikasi[device_autentikasi]['username'])
        device_password = str(list_autentikasi[device_autentikasi]['password'])

        for y in range(len(list_device_interface)):
            if device_vendor == 'MikroTik':
                list_data = []
                interface_name = list_device_interface[y]['name']

                capture_log.logging.info(
                    f"Mulai pengecekan interface {interface_name} from {device_identity}")

                try:
                    connection = routeros_api.RouterOsApiPool(host=device_ip,
                                                              port=8728,
                                                              username=device_username,
                                                              password=device_password,
                                                              plaintext_login=True)
                    api = connection.get_api()
                    command_interface = api.get_resource('interface')
                    try:
                        interface_comment = command_interface.get(name=interface_name)[
                            0]['comment']
                    except:
                        interface_comment = ""
                    interface_status = command_interface.get(
                        name=interface_name)[0]['running']
                    if interface_status:
                        interface_status = "Running"
                    interface_up_time = command_interface.get(name=interface_name)[
                        0]['last-link-up-time']
                    interface_down = command_interface.get(name=interface_name)[
                        0]['link-downs']
                    interface_receive_before = int(command_interface.get(name=interface_name)[
                        0]['rx-byte'])
                    interface_transmite_before = int(command_interface.get(name=interface_name)[
                        0]['tx-byte'])
                    time.sleep(1)
                    interface_receive_now = int(command_interface.get(name=interface_name)[
                        0]['rx-byte'])
                    interface_transmite_now = int(command_interface.get(name=interface_name)[
                        0]['tx-byte'])

                    result_receive = (interface_receive_now -
                                      interface_receive_before) / 1000
                    result_transmite = (
                        interface_transmite_now - interface_transmite_before) / 1000

                    # Memasukkan Data Kedalam List data[]
                    list_data.append(count)
                    list_data.append(device_identity)
                    list_data.append(interface_name)
                    list_data.append(interface_comment)
                    list_data.append(result_receive)
                    list_data.append(result_transmite)
                    list_data.append(interface_status)
                    list_data.append(interface_up_time)
                    list_data.append(interface_down)
                    list_data.append('Success')
                    list_data.append(timestamp)
                    data.append(list_data)
                    insertLinkSfp(device_identity, interface_name, interface_comment, result_receive,
                                    result_transmite, interface_status, interface_up_time, interface_down, "Success", timestamp)
                except Exception as e:
                    # Memasukkan Data Kedalam List data[]
                    list_data.append(count)
                    list_data.append(device_identity)
                    list_data.append(interface_name)
                    list_data.append(interface_comment)
                    list_data.append(result_receive)
                    list_data.append(result_transmite)
                    list_data.append(interface_status)
                    list_data.append(interface_up_time)
                    list_data.append(interface_down)
                    list_data.append(e)
                    list_data.append(timestamp)
                    data.append(list_data)
                    insertLinkSfp(device_identity, interface_name, interface_comment, result_receive,
                                    result_transmite, interface_status, interface_up_time, interface_down, e, timestamp)
                    continue
            count += 1
    with open(os.path.join(os.path.dirname(__file__)) + '/files/link_sfp.csv', 'w', encoding='UTF8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(data)
