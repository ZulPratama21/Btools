import pymysql
from database.connection import create_conntection

def selectAuth(login_id):
    cursor = create_conntection().cursor(pymysql.cursors.DictCursor)
    query = f"SELECT username, password from configuration_periodic_checking_auth WHERE login_id = '{login_id}'"
    cursor.execute(query)
    results = cursor.fetchall()
    cursor.close()
    create_conntection().close()

    return results

def selectLinkMainJoinLinkMainStations():

    cursor = create_conntection().cursor(pymysql.cursors.DictCursor)
    query = """ 
    SELECT configuration_periodic_checking_link_main.identity, configuration_periodic_checking_link_main.ip,
    configuration_periodic_checking_link_main.vendor,configuration_periodic_checking_link_main.login_id,
    configuration_periodic_checking_link_main_stations.identity,
    configuration_periodic_checking_link_main_stations.alias,
    configuration_periodic_checking_link_main_stations.ip, 
    configuration_periodic_checking_link_main_stations.mac_address,
    configuration_periodic_checking_link_main_stations.media,
    configuration_periodic_checking_link_main_stations.login_id, 
    configuration_periodic_checking_link_main_stations.min_bandwidth

    FROM configuration_periodic_checking_link_main
    JOIN configuration_periodic_checking_link_main_stations
    ON configuration_periodic_checking_link_main.identity = configuration_periodic_checking_link_main_stations.device_id
    """
    cursor.execute(query)
    results = cursor.fetchall()
    cursor.close()
    create_conntection().close()

    return results

def selectLinkBackupJoinLinkBackupStations():

    cursor = create_conntection().cursor(pymysql.cursors.DictCursor)
    query = """ 
    SELECT configuration_periodic_checking_link_backup.identity, configuration_periodic_checking_link_backup.ip,
    configuration_periodic_checking_link_backup.vendor,configuration_periodic_checking_link_backup.login_id,
    configuration_periodic_checking_link_backup_stations.identity,
    configuration_periodic_checking_link_backup_stations.alias, 
    configuration_periodic_checking_link_backup_stations.ip, 
    configuration_periodic_checking_link_backup_stations.mac_address,
    configuration_periodic_checking_link_backup_stations.media,
    configuration_periodic_checking_link_backup_stations.login_id, 
    configuration_periodic_checking_link_backup_stations.min_bandwidth

    FROM configuration_periodic_checking_link_backup
    JOIN configuration_periodic_checking_link_backup_stations
    ON configuration_periodic_checking_link_backup.identity = configuration_periodic_checking_link_backup_stations.device_id
    """
    cursor.execute(query)
    results = cursor.fetchall()
    cursor.close()
    create_conntection().close()

    return results

def insertLinkBackup(address, source, destination, alias, ping, receive, transmite, source_frequency, source_tx_power, message, time):

    try:
        conn = create_conntection()
        cursor = conn.cursor()
        cursor.execute(f"""INSERT INTO automation_periodic_checking_link_backup (address, source, destination, alias, ping, receive, transmit, source_frequency, source_tx_power, message, time)
        VALUES ('{address}', '{source}', '{destination}', '{alias}', '{ping}', '{receive}', '{transmite}', '{source_frequency}', '{source_tx_power}', '{message}', '{time}'); 
        """)
        conn.commit()
        print("Data inserted successfully!")

    except Exception as err:
        print("Error inserting data:", err)

    return None


def insertLinkMain(address, source, destination, alias, ping, receive, transmite, source_frequency, source_tx_power, message, time):

    try:
        conn = create_conntection()
        cursor = conn.cursor()
        cursor.execute(f"""INSERT INTO automation_periodic_checking_link_main (address, source, destination, alias, ping, receive, transmit, source_frequency, source_tx_power, message, time)
        VALUES ('{address}', '{source}', '{destination}', '{alias}', '{ping}', '{receive}', '{transmite}', '{source_frequency}', '{source_tx_power}', '{message}', '{time}'); 
        """)
        conn.commit()
        print("Data inserted successfully!")

    except Exception as err:
        print("Error inserting data:", err)

    return None


def insertLinkPeering(source, destination, ping, state, message, time):
    try:
        conn = create_conntection()
        cursor = conn.cursor()
        cursor.execute(f"""INSERT INTO automation_periodic_checking_link_peering (source, destination, ping, state, message, time) 
        VALUES ('{source}','{destination}','{ping}','{state}','{message}','{time}')""")
        conn.commit()
        print("Data inserted successfully!")

    except Exception as err:
        print("Error inserting data:", err)

    return None


def insertLinkSfp(source, interface, comment, receive, transmit, state, last_link_up, link_down, message, time):
    try:
        conn = create_conntection()
        cursor = conn.cursor()
        cursor.execute(f"""INSERT INTO automation_periodic_checking_link_sfp (source, interface, comment, receive, transmit, state, last_link_up, link_down, message, time)
        VALUES ('{source}', '{interface}', '{comment}', '{receive}', '{transmit}', '{state}', '{last_link_up}', '{link_down}', '{message}', '{time}');""")
        conn.commit()
        print("Data inserted successfully!")

    except Exception as err:
        print("Error inserting data:", err)

    return None


def insertLinkTransit(source, destination, ping, state, message, time):
    try:
        conn = create_conntection()
        cursor = conn.cursor()
        cursor.execute(f"""INSERT INTO automation_periodic_checking_link_transit (source, destination, ping, state, message, time) 
        VALUES ('{source}','{destination}','{ping}','{state}','{message}','{time}')""")
        conn.commit()
        print("Data inserted successfully!")

    except Exception as err:
        print("Error inserting data:", err)

    return None
