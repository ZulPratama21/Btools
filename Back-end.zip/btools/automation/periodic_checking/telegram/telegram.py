import requests, datetime

"""Konfig Telegram"""
token = "5633721828:AAEt3FPdFxL7TD7KgllHnW2k0C_pghFhHoI" #Production
chat_id = -736328414 #Production

class Send:
    def logUpdate():
        text = (
"""
✨ Informasi Versi ✨
Versi 2.3
- Penambahan fitur logging untuk mengetahui error yang terjadi

Versi 2.2
- Perubahan Output pesan Link status Up, status Down dan Bandwidth Terkecil yang sebelumnya dari source, menjadi destination

Versi 2.1
- Kirim Data Weekly (Link Main, Link Backup, Link SFP, Link Transit Dan Link Peering) Setiap Hari Kamis

Versi 2.0
- Kirim File Output Ke Telegram
- Analisa Data Link Main Dan Link Backup (Ringkasa Data, Rekomendasi Tunning, Link Up/Down Dan Bandwith Terkecil)

Versi 1.0
- Pengecekan Link Main
- Pengecekan Link Backup
- Pengecekan Link SFP
- Pengecekan Link Transit
- Pengecekan Link Peering
""")
        requests.get(f'https://api.telegram.org/bot{token}/sendMessage?chat_id={chat_id}&text={text}')
        
    def start():
        datetime_now = datetime.datetime.now()

        text = (
f"""
▶️ %09Program Berjalan : {datetime_now}
""")
        requests.get(f'https://api.telegram.org/bot{token}/sendMessage?chat_id={chat_id}&text={text}')

    def link_backup():
        from periodic_checking.arithmetic.link_backup import LearnLinkBackup as LEARN_LINKBACKUP
        text = (
f"""
⚡ 𝗣𝗲𝗻𝗴𝗲𝗰𝗲𝗸𝗮𝗻 𝗟𝗶𝗻𝗸 𝗕𝗮𝗰𝗸𝘂𝗽 ⚡

𝙍𝙞𝙣𝙜𝙠𝙖𝙨𝙖𝙣
🕓 %09Jam  %09%09: {datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S")}
✅ %09Up   %09%09%09%09: {LEARN_LINKBACKUP().count_status_up()} Link
❌ %09Down %09: {LEARN_LINKBACKUP().count_status_down()} Link 
📊 %09Total Speedtest %09: {LEARN_LINKBACKUP().sum_speedtest()} Mbps

𝙍𝙚𝙠𝙤𝙢𝙚𝙣𝙙𝙖𝙨𝙞 𝙏𝙪𝙣𝙣𝙞𝙣𝙜
{LEARN_LINKBACKUP().recommend_tunning()}
========= 𝐑𝐚𝐰 𝐃𝐚𝐭𝐚 =========
𝙇𝙞𝙣𝙠 𝙐𝙥
{LEARN_LINKBACKUP().status_up()}
𝙇𝙞𝙣𝙠 𝘿𝙤𝙬𝙣
{LEARN_LINKBACKUP().status_down()}
𝘽𝙖𝙣𝙙𝙬𝙞𝙩𝙝 𝙏𝙚𝙧𝙠𝙚𝙘𝙞𝙡
{LEARN_LINKBACKUP().sort_min_n(3)}
""")
        requests.get(f'https://api.telegram.org/bot{token}/sendMessage?chat_id={chat_id}&text={text}')

    def link_main():
        from periodic_checking.arithmetic.link_main import LearnLinkMain as LEARN_LINKMAIN
        text = (
f"""
⚡ 𝗣𝗲𝗻𝗴𝗲𝗰𝗲𝗸𝗮𝗻 𝗟𝗶𝗻𝗸 𝗠𝗮𝗶𝗻 ⚡

𝙍𝙞𝙣𝙜𝙠𝙖𝙨𝙖𝙣
🕓 %09Jam  %09%09: {datetime.datetime.now().strftime("%Y-%m-%d %I:%M:%S")}
✅ %09Up   %09%09%09%09: {LEARN_LINKMAIN().count_status_up()} Link
❌ %09Down %09: {LEARN_LINKMAIN().count_status_down()} Link 
📊 %09Total Speedtest %09: {LEARN_LINKMAIN().sum_speedtest()} Mbps

𝙍𝙚𝙠𝙤𝙢𝙚𝙣𝙙𝙖𝙨𝙞 𝙏𝙪𝙣𝙣𝙞𝙣𝙜
{LEARN_LINKMAIN().recommend_tunning()}
========= 𝐑𝐚𝐰 𝐃𝐚𝐭𝐚 =========
𝙇𝙞𝙣𝙠 𝙐𝙥
{LEARN_LINKMAIN().status_up()}
𝙇𝙞𝙣𝙠 𝘿𝙤𝙬𝙣
{LEARN_LINKMAIN().status_down()}
𝘽𝙖𝙣𝙙𝙬𝙞𝙩𝙝 𝙏𝙚𝙧𝙠𝙚𝙘𝙞𝙡
{LEARN_LINKMAIN().sort_min_n(3)}
""")
        requests.get(f'https://api.telegram.org/bot{token}/sendMessage?chat_id={chat_id}&text={text}')

    def files(nameFiles):
        document = open(f'{nameFiles}', 'rb')
        document_dict = {'document': document}
        
        requests.post(f'https://api.telegram.org/bot{token}/sendDocument?chat_id={chat_id}', files=document_dict)