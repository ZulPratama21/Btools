import json
import routeros_api
import csv
import datetime
import os
from periodic_checking.logger import capture_log
from periodic_checking.query import *

config_authentication = json.load(open(os.path.join(
    os.path.dirname(__file__)) + '/configuration/authentication.json'))
config_linkTransit = json.load(open(os.path.join(
    os.path.dirname(__file__)) + '/configuration/link_transit.json'))


def run():
    capture_log.logging.info(f"======LINK TRANSIT======")
    # Header .csv
    header = ['no', 'source', 'destination',
              'ping', 'state', 'message', 'time']
    # Tampung Data
    data = []

    list_autentikasi = config_authentication['autentikasi']
    list_router = config_linkTransit['link_transit']['device']

    for i in range(len(list_router)):
        # Default Value
        router_identity = ""
        bpg_peers_name = ""
        bpg_peers_state = ""
        bgp_session_name = ""
        ping_average = 0
        bgp_session_established = ""

        count = i + 1
        timestamp = str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M"))
        router_identity = list_router[i]['identity']
        router_ip = list_router[i]['ip']
        params = list_router[i]['routing']['params']
        list_bgp = list_router[i]['routing']['bgp']
        router_vendor = list_router[i]['vendor']
        router_autentikasi = list_router[i]['autentikasi']

        username = str(list_autentikasi[router_autentikasi]['username'])
        password = str(list_autentikasi[router_autentikasi]['password'])

        for y in range(len(list_bgp)):
            list_data = []
            if router_vendor == 'MikroTik':
                if params == 'peers':
                    bpg_peers_name = list_bgp[y]['name']
                    capture_log.logging.info(
                        f"Mulai pengecekan peers bgp {bpg_peers_name} from {router_identity}")
                    try:
                        connection = routeros_api.RouterOsApiPool(host=router_ip,
                                                                  port=8728,
                                                                  username=username,
                                                                  password=password,
                                                                  plaintext_login=True)
                        api = connection.get_api()
                        command_bgp = api.get_resource('routing/bgp/peer')
                        try:
                            bpg_peers_state = command_bgp.get(
                                name=bpg_peers_name)[0]['state']
                            bpg_peers_remote_address = command_bgp.get(name=bpg_peers_name)[
                                0]['remote-address']

                            command_ping = api.get_binary_resource(
                                '/').call('ping', {'address': str(bpg_peers_remote_address).encode(), 'count': b'5'})
                            for i in command_ping:
                                ping_average = str(i['avg-rtt'], 'UTF-8')
                        except:
                            ping_average = 'null'
                        # Memasukkan Data Kedalam List data[]
                        list_data.append(count)
                        list_data.append(router_identity)
                        list_data.append(bpg_peers_name)
                        list_data.append(ping_average)
                        list_data.append(bpg_peers_state)
                        list_data.append('Success')
                        list_data.append(timestamp)
                        data.append(list_data)
                        insertLinkTransit(
                            router_identity, bpg_peers_name, ping_average, bpg_peers_state, "Success", timestamp)

                    except Exception as e:
                        # Memasukkan Data Kedalam List data[]
                        list_data.append(count)
                        list_data.append(router_identity)
                        list_data.append(bpg_peers_name)
                        list_data.append(ping_average)
                        list_data.append(bpg_peers_state)
                        list_data.append(e)
                        list_data.append(timestamp)
                        data.append(list_data)
                        insertLinkTransit(
                            router_identity, bpg_peers_name, ping_average, bpg_peers_state, e, timestamp)

                elif params == 'sessions':
                    bgp_session_name = list_bgp[y]['name']
                    try:
                        connection = routeros_api.RouterOsApiPool(host=router_ip,
                                                                  port=8728,
                                                                  username=username,
                                                                  password=password,
                                                                  plaintext_login=True)
                        api = connection.get_api()
                        command_bgp = api.get_resource('routing/bgp/session')
                        bgp_session_established = command_bgp.get(
                            name=bgp_session_name)[0]['established']
                        if bgp_session_established:
                            bgp_session_established = "established"
                        try:
                            bpg_session_remote_address = command_bgp.get(
                                name=bgp_session_name)[0]['remote.address']

                            command_ping = api.get_binary_resource(
                                '/').call('ping', {'address': str(bpg_session_remote_address).encode(), 'count': b'5'})
                            for i in command_ping:
                                ping_average = str(i['avg-rtt'], 'UTF-8')
                        except:
                            ping_average = 'null'
                        # Memasukkan Data Kedalam List data[]
                        list_data.append(count)
                        list_data.append(router_identity)
                        list_data.append(bgp_session_name)
                        list_data.append(ping_average)
                        list_data.append(bgp_session_established)
                        list_data.append('Success')
                        list_data.append(timestamp)
                        data.append(list_data)
                        insertLinkTransit(
                            router_identity, bgp_session_name, ping_average, bgp_session_established, "Success", timestamp)

                    except Exception as e:
                        # Memasukkan Data Kedalam List data[]
                        list_data.append(count)
                        list_data.append(router_identity)
                        list_data.append(bgp_session_name)
                        list_data.append(ping_average)
                        list_data.append(bgp_session_established)
                        list_data.append(e)
                        list_data.append(timestamp)
                        data.append(list_data)
                        insertLinkTransit(
                            router_identity, bgp_session_name, ping_average, bgp_session_established, e, timestamp)
    with open(os.path.join(os.path.dirname(__file__)) + '/files/link_transit.csv', 'w', encoding='UTF8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(data)
