import logging, os

logging.basicConfig(level=logging.INFO, filename=os.path.join(os.path.dirname(__file__)) + "/logger.log",filemode="w", format="%(asctime)s %(levelname)s %(message)s")
