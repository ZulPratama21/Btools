import json
import csv
import datetime
import routeros_api
import paramiko
import re
import os
from periodic_checking.logger import capture_log
from periodic_checking.query import *

def run():
    capture_log.logging.info(f"======LINK BACKUP======")
    # Header .csv
    header = ['no', 'source', 'destination', 'alias', 'ping', 'receive', 'transmite',
              'source_frequency', 'Source_tx_power', 'media', 'message', 'time']

    # Tampung Data
    data = []

    list_apt = selectLinkBackupJoinLinkBackupStations()

    for i in range(len(list_apt)):
        # Default Value
        apt_identity = ""
        apt_station_identity = ""
        apt_alias = ""
        ping = ""
        receive = 0
        transmite = 0
        get_frequency = 0
        get_tx_power = 0
        media = list_apt[i]['media']
        message = ""

        count = i + 1
        timestamp = str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M"))
        apt_identity = list_apt[i]['identity']
        apt_ip = list_apt[i]['ip']
        apt_autentikasi = list_apt[i]['login_id']
        apt_vendor = list_apt[i]['vendor']
        apt_username = str(selectAuth(apt_autentikasi)[0]['username'])
        apt_password = str(selectAuth(apt_autentikasi)[0]['password'])

        list_data = []

        apt_station_identity = list_apt[i]['configuration_periodic_checking_link_backup_stations.identity']
        apt_alias = list_apt[i]['alias']
        apt_station_ip = list_apt[i]['configuration_periodic_checking_link_backup_stations.ip']
        apt_station_autentikasi = list_apt[i]['configuration_periodic_checking_link_backup_stations.login_id']

        apt_station_username = str(selectAuth(apt_station_autentikasi)[0]['username'])
        apt_station_password = str(selectAuth(apt_station_autentikasi)[0]['password'])

        capture_log.logging.info(
            f"Mulai pengetesan link {apt_identity} to {apt_station_identity}")
        
        if apt_vendor == 'MikroTik':
            # Mencoba Koneksi API
            try:
                connection = routeros_api.RouterOsApiPool(host=apt_ip,
                                                            port=8728,
                                                            username=apt_username,
                                                            password=apt_password,
                                                            plaintext_login=True)
                api = connection.get_api()

                # Mencoba Ping Ke Destination
                try:
                    command_ping = api.get_binary_resource(
                        '/').call('ping', {'address': str(apt_station_ip).encode(), 'count': b'5'})
                    for output in command_ping:
                        ping = str(output['avg-rtt'], 'UTF-8')

                        # Mencoba Bandwith Test
                    try:
                        message = "Success"
                        command_receive = api.get_binary_resource('/tool').call(
                            'bandwidth-test', {
                                'address': str(apt_station_ip).encode(),
                                'user': apt_station_username.encode(),
                                'password': apt_station_password.encode(),
                                'protocol': b'tcp',
                                'duration': b'20',
                                'direction': b'receive'
                            })
                        for output in command_receive:
                            receive = round(
                                int(output['rx-total-average']) / 1_000_000, 2)

                        command_transmite = api.get_binary_resource('/tool').call(
                            'bandwidth-test', {
                                'address': str(apt_station_ip).encode(),
                                'user': apt_station_username.encode(),
                                'password': apt_station_password.encode(),
                                'protocol': b'tcp',
                                'duration': b'20',
                                'direction': b'transmit'
                            })
                        for output in command_transmite:
                            transmite = round(
                                int(output['tx-total-average']) / 1_000_000, 2)
                    except Exception as e:
                        message = "Link Test Failed"

                    # Mencoba Get Info Wireless
                    try:
                        command_wireless = api.get_resource(
                            '/interface/wireless').get(default_name='wlan1')[0]
                        get_frequency = command_wireless['frequency']
                        get_tx_power = command_wireless['tx-power-mode']
                    except:
                        get_frequency = 0
                        get_tx_power = ""
                except Exception as e:
                    message = "Ping RTO"

            except Exception as e:
                message = "Koneksi API Failed"

            # Memasukkan Data Kedalam List data[]
            list_data.append(count)
            list_data.append(apt_identity)
            list_data.append(apt_station_identity)
            list_data.append(apt_alias)
            list_data.append(ping)
            list_data.append(str(receive))
            list_data.append(str(transmite))
            list_data.append(get_frequency)
            list_data.append(get_tx_power)
            list_data.append(media)
            list_data.append(message)
            list_data.append(timestamp)
            data.append(list_data)
            capture_log.logging.info(
                f"Pengetesan link {apt_identity} to {apt_station_identity} berhasil")
            insertLinkBackup(apt_ip, apt_identity, apt_station_identity, apt_alias, ping,
                            receive, transmite, get_frequency, get_tx_power, message, timestamp)

        elif apt_vendor == 'Cambium':
            apt_station_mac_address = list_apt[i]['mac_address']

            # Membuat Koneksi SSH
            try:
                client = paramiko.client.SSHClient()
                client.set_missing_host_key_policy(
                    paramiko.AutoAddPolicy())
                client.connect(apt_ip, username=apt_username,
                                password=apt_password)

                # Mencoba Ping Ke Destination
                try:
                    stdin, stdout, stderr = client.exec_command(
                        f"ping {apt_station_ip} -c 5")
                    output_ping = stdout.read().decode()

                    ping = re.findall(
                        'time=(\d+.\d+\s\w+)', output_ping)[2]
                except Exception as e:
                    message = "Ping RTO"
                stdin.close()

                # Mencoba Link Test
                try:
                    stdin, stdout, stderr = client.exec_command(
                        f"linktest {apt_station_mac_address}")
                    output_bandwith_test = stdout.read().decode()
                    status_linktest = re.findall(
                        'Result:\s+(\w+)', output_bandwith_test)[0]

                    # Cek Status Link Test
                    if status_linktest == 'failed':
                        message = 'Link Test Failed'
                    elif status_linktest == 'success':
                        message = 'Success'
                        transmite = int(re.findall(
                            'Uplink:\s+(\d+)', output_bandwith_test)[0]) / 1000
                        receive = int(re.findall(
                            'Downlink:\s+(\d+)', output_bandwith_test)[0]) / 1000
                except Exception as e:
                    message = "Tidak Ada Output"
                stdin.close()

            except Exception as e:
                message = "Koneksi SSH Failed"
            # Memasukkan Data Kedalam List data[]
            list_data.append(count)
            list_data.append(apt_identity)
            list_data.append(apt_station_identity)
            list_data.append(apt_alias)
            list_data.append(ping)
            list_data.append(str(receive))
            list_data.append(str(transmite))
            list_data.append(get_frequency)
            list_data.append(get_tx_power)
            list_data.append(media)
            list_data.append(message)
            list_data.append(timestamp)
            data.append(list_data)
            capture_log.logging.info(
                f"Pengetesan link {apt_identity} to {apt_station_identity} berhasil")
            insertLinkBackup(apt_ip, apt_identity, apt_station_identity, apt_alias, ping,
                            receive, transmite, get_frequency, get_tx_power, message, timestamp)
    with open(os.path.join(os.path.dirname(__file__)) + '/files/link_backup.csv', 'w', encoding='UTF8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(data)
