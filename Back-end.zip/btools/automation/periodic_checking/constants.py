'''
LINK BACKUP
'''
c_link_backup_speedtest_min = 30

'''
LINK MAIN
'''
c_link_main_speedtest_min = 40