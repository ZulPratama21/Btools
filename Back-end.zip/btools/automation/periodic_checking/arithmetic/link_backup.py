import pandas as pd
import matplotlib.pyplot as plt
import sqlite3
import datetime
from periodic_checking.constants import *
from database.connection import *

# Koneksi Database
conn = create_conntection()


class LearnLinkBackup:
    def __init__(self, data=pd.read_sql_query(f"SELECT * FROM automation_periodic_checking_link_backup WHERE time LIKE '{datetime.datetime.now().strftime('%Y-%m-%d')}%'", conn)):
        self.data = data
        # Jumlahkan Receive + Transmite
        data_sum = self.data['receive'] + self.data['transmit']
        self.data['result_speedtest'] = data_sum.round(2)

    # Mengambil data terbesar sebanyak n
    def sort_max_n(self, n):
        list_sort_max_n = self.data[['destination', 'result_speedtest']].nlargest(
            n, "result_speedtest").reset_index(drop=True).dropna().values.tolist()
        result_sort_max_n = ""

        for word in list_sort_max_n:
            result_sort_max_n += "- " + str(word[0]) + "\n"

        return result_sort_max_n

    # Mengambil data terkecil sebanyak n
    def sort_min_n(self, n):
        list_sort_min_n = self.data[['destination', 'result_speedtest']].nsmallest(
            n, "result_speedtest").reset_index(drop=True).dropna().values.tolist()
        result_sort_min_n = ""

        for word in list_sort_min_n:
            result_sort_min_n += "- " + str(word[0]) + "\n"

        return result_sort_min_n

    # Urutkan list data terbesear
    def sort_max(self):
        list_sort_max = self.data.sort_values(by=['result_speedtest'], ascending=False)[
            ['destination', 'result_speedtest']].reset_index(drop=True).dropna().values.tolist()
        result_sort_max = ""

        for word in list_sort_max:
            result_sort_max += "- " + str(word[0]) + "\n"

        return result_sort_max

    # Urutkan list data terkecil
    def sort_min(self):
        list_sort_min = self.data.sort_values(by=['result_speedtest'], ascending=True)[
            ['destination', 'result_speedtest']].reset_index(drop=True).dropna().values.tolist()
        result_sort_min = ""

        for word in list_sort_min:
            result_sort_min += "- " + str(word[0]) + "\n"

        return result_sort_min

    # Sum result_speedtest
    def sum_speedtest(self):
        return self.data.result_speedtest.sum().round(2)

    # Cek List Status Up
    def status_up(self):
        list_status_up = self.data[['source', 'destination', 'message']].where(
            (self.data['message'] == "Success")).dropna().values.tolist()
        result_status_up = ""

        for word in list_status_up:
            result_status_up += "- " + str(word[1]) + "\n"

        return result_status_up

    # Cek List Status Down
    def status_down(self):
        list_status_down = self.data[['source', 'destination', 'message']].where(
            (self.data['message'] != "Success")).dropna().values.tolist()
        result_status_down = ""

        for word in list_status_down:
            result_status_down += "- " + str(word[1]) + "\n"

        return result_status_down

    # Cek Status Up
    def count_status_up(self):
        return self.data.where((self.data['message'] == "Success")).count()[0]

    # Cek Status Down
    def count_status_down(self):
        return self.data.where((self.data['message'] != "Success")).count()[0]

    # List Rekomendasi Tunning
    def recommend_tunning(self):
        list_recommend_tunning = self.data[['source', 'destination', 'result_speedtest']].where(
            (self.data['result_speedtest'] < c_link_main_speedtest_min) & (self.data['message'] == 'Success')).dropna().values.tolist()
        result_recommend_tunning = ""

        for word in list_recommend_tunning:
            result_recommend_tunning += "- " + \
                str(word[0]) + " > " + str(word[1]) + "\n"

        return result_recommend_tunning
