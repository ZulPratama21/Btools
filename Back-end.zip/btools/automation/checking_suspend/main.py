from puresnmp import get as SNMP_GET
from checking_suspend import constants as CONSTANTS
from checking_suspend.query import *
import time
import datetime
import routeros_api

data_bhome = selectToubleshootBhomeJoinTroubleshootParent()
data_bcorp = selectToubleshootBcorpJoinTroubleshootParent()
timestamp = str(datetime.datetime.now())

def run():
    deleteSuspend()
    for data in data_bhome:
        id_customer = data['ID_Customer']
        name = data['Name']
        ip_parent = data['ip_parent']
        username_parent = data['username_parent']
        password_parent = data['password_parent']
        remote_address = data['ip_client']
        
        connection = routeros_api.RouterOsApiPool(
            ip_parent, username=username_parent, password=password_parent, plaintext_login=True)
        api = connection.get_api()

        list_address_list_details = api.get_resource('ip/firewall/address-list').get(address=remote_address)
        try:
            list_address_list_allow_check = api.get_resource('ip/firewall/address-list').get(address=remote_address)[0]['list']
        except:
            list_address_list_allow_check = 0
        try:
            list_address_creation_time = api.get_resource('ip/firewall/address-list').get(address=remote_address)[0]['creation-time']
        except:
            list_address_creation_time = "xxx/00/0000 00:00:00"

        if list_address_list_allow_check == 'allow':
            list_address_list_status_inet= 1
        else:
            list_address_list_status_inet = 0

        insertSuspend(id_customer,name,list_address_creation_time,list_address_list_status_inet, timestamp)
    print("Update Data Suspend Bhome Done")

    for data in data_bcorp:
        id_customer = data['ID_Customer']
        name = data['Name']
        ip_parent = data['ip_parent']
        username_parent = data['username_parent']
        password_parent = data['password_parent']
        remote_address = data['ip_client']
        
        connection = routeros_api.RouterOsApiPool(
            ip_parent, username=username_parent, password=password_parent, plaintext_login=True)
        api = connection.get_api()

        list_address_list_details = api.get_resource('ip/firewall/address-list').get(address=remote_address)
        try:
            list_address_list_allow_check = api.get_resource('ip/firewall/address-list').get(address=remote_address)[0]['list']
        except:
            list_address_list_allow_check = 0
        try:
            list_address_creation_time = api.get_resource('ip/firewall/address-list').get(address=remote_address)[0]['creation-time']
        except:
            list_address_creation_time = "xxx/00/0000 00:00:00"

        if list_address_list_allow_check == 'allow':
            list_address_list_status_inet= 1
        else:
            list_address_list_status_inet = 0

        insertSuspend(id_customer,name,list_address_creation_time,list_address_list_status_inet, timestamp)
    print("Update Data Suspend Bcorp Done")

