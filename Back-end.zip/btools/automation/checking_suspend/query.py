import pymysql
from database.connection import create_conntection

"""
Entity : troubleshoot_bhome
"""
def selectToubleshootBhomeJoinTroubleshootParent():
    cursor = create_conntection().cursor(pymysql.cursors.DictCursor)
    query = f""" 
    SELECT troubleshoot_bhome.ID_Customer, troubleshoot_bhome.Name, troubleshoot_bhome.Secret_User, troubleshoot_bhome.ID_Noc, troubleshoot_bhome.IP_Address as 'ip_client', troubleshoot_parent.IP_Address as 'ip_parent', troubleshoot_olt.IP_Address as 'ip_olt', authentication.Username AS username_parent, authentication.`Password` AS password_parent
    FROM troubleshoot_bhome
    INNER JOIN troubleshoot_parent
    ON troubleshoot_bhome.ID_Parent = troubleshoot_parent.ID_Parent
    INNER JOIN troubleshoot_olt
    ON troubleshoot_bhome.ID_OLT = troubleshoot_olt.ID_OLT
    INNER JOIN authentication
    ON authentication.ID_Authentication = troubleshoot_parent.ID_Authentication
    """
    cursor.execute(query)
    results = cursor.fetchall()
    cursor.close()
    create_conntection().close()

    return results

def selectToubleshootBcorpJoinTroubleshootParent():
    cursor = create_conntection().cursor(pymysql.cursors.DictCursor)
    query = f""" 
    SELECT troubleshoot_bcorp.ID_Customer, troubleshoot_bcorp.Name, troubleshoot_bcorp.IP_Address as 'ip_client', troubleshoot_parent.IP_Address as 'ip_parent', authentication.Username AS username_parent, authentication.`Password` AS password_parent
    FROM troubleshoot_bcorp
    INNER JOIN troubleshoot_parent
    ON troubleshoot_bcorp.ID_Parent = troubleshoot_parent.ID_Parent
    INNER JOIN authentication
    ON authentication.ID_Authentication = troubleshoot_parent.ID_Authentication
    """
    cursor.execute(query)
    results = cursor.fetchall()
    cursor.close()
    create_conntection().close()

    return results
    
def insertSuspend(ID_Customer, Name, Suspend_By_Router, Status_Internet, Update_at):
    try:
        conn = create_conntection()
        cursor = conn.cursor()
        cursor.execute(f"""INSERT INTO spreadsheet_suspend (ID_Customer, Name, Suspend_By_Router, Status_Internet, Update_at) VALUES ('{ID_Customer}', '{Name}', '{Suspend_By_Router}', {Status_Internet}, '{Update_at}');""")
        conn.commit()
        print("Data inserted successfully!")

    except Exception as err:
        print("Error inserting data:", err)

    return None    

def deleteSuspend():
    try:
        conn = create_conntection()
        cursor = conn.cursor()
        cursor.execute(f"""DELETE FROM spreadsheet_suspend;""")
        conn.commit()
    except Exception as err:
        print(err)

    return None