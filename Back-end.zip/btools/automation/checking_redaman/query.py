import pymysql
from database.connection import create_conntection

def selectTroubleshotBhomeJoinOlt():
    cursor = create_conntection().cursor(pymysql.cursors.DictCursor)
    query = """ 
    SELECT troubleshoot_bhome.ID_Customer, troubleshoot_bhome.ID_Noc, troubleshoot_olt.IP_Address as 'ip_olt'
    FROM troubleshoot_bhome
    INNER JOIN troubleshoot_parent
    ON troubleshoot_bhome.ID_Parent = troubleshoot_parent.ID_Parent
    INNER JOIN troubleshoot_olt
    ON troubleshoot_bhome.ID_OLT = troubleshoot_olt.ID_OLT
    ORDER BY ID_Noc
    """
    cursor.execute(query)
    results = cursor.fetchall()
    cursor.close()
    create_conntection().close()

    return results

def insertMonitoringBhome(ID_Customer, State, Redaman, Offline, Created_at):
    try:
        conn = create_conntection()
        cursor = conn.cursor()
        cursor.execute(f"""INSERT INTO monitoring_bhome (ID_Customer, State, Redaman, Offline, Created_at) VALUES ('{ID_Customer}', '{State}', {Redaman}, '{Offline}', '{Created_at}');""")
        conn.commit()
        print("Data inserted successfully!")

    except Exception as err:
        print("Error inserting data:", err)

    return None