from puresnmp import get as SNMP_GET
from checking_redaman import constants as CONSTANTS
from checking_redaman.query import *
import time, datetime

data = selectTroubleshotBhomeJoinOlt()

def run():
    for _ in data:
        ID_CUSTOMER = _['ID_Customer']
        ID_NOC = _['ID_Noc']
        IP_OLT = _['ip_olt']
        timestamp = str(datetime.datetime.now())
        
        try:
            NUMBER_PORT = str(ID_NOC)[1:3]
            NUMBER_PORT_ONU = str(ID_NOC)[3:5]

            DICT_OID = {
                'ONU': {
                    'STATE': str(CONSTANTS.CONSTANT_OIDS['ONU']['STATE']) + str(CONSTANTS.CONSTANT_OID_PORT['port'][NUMBER_PORT]['OID']) + '.' + str(NUMBER_PORT_ONU),
                    'REDAMAN': {
                        'rx': str(CONSTANTS.CONSTANT_OIDS['ONU']['REDAMAN']['rx']) + str(CONSTANTS.CONSTANT_OID_PORT['port'][NUMBER_PORT]['OID']) + '.' + str(NUMBER_PORT_ONU) + '.1'
                    },
                    'AUTHPASS': str(CONSTANTS.CONSTANT_OIDS['ONU']['AUTHPASS']) + str(CONSTANTS.CONSTANT_OID_PORT['port'][NUMBER_PORT]['OID']) + '.' + str(NUMBER_PORT_ONU),
                    'OFFLINE': str(CONSTANTS.CONSTANT_OIDS['ONU']['OFFLINE']) + str(CONSTANTS.CONSTANT_OID_PORT['port'][NUMBER_PORT]['OID']) + '.' + str(NUMBER_PORT_ONU),
                    'TYPE': str(CONSTANTS.CONSTANT_OIDS['ONU']['TYPE']) + str(CONSTANTS.CONSTANT_OID_PORT['port'][NUMBER_PORT]['OID']) + '.' + str(NUMBER_PORT_ONU),
                    'NAME': str(CONSTANTS.CONSTANT_OIDS['ONU']['NAME']) + str(CONSTANTS.CONSTANT_OID_PORT['port'][NUMBER_PORT]['OID']) + '.' + str(NUMBER_PORT_ONU),
                    'SN': str(CONSTANTS.CONSTANT_OIDS['ONU']['SN']) + str(CONSTANTS.CONSTANT_OID_PORT['port'][NUMBER_PORT]['OID']) + '.' + str(NUMBER_PORT_ONU),
                }
            }

        
            # Get Data From SNMP
            get_onu_state = SNMP_GET(
                IP_OLT, 'intbnet', DICT_OID['ONU']['STATE'])
            get_onu_redaman_rx = (SNMP_GET(IP_OLT, 'intbnet',
                                      DICT_OID['ONU']['REDAMAN']['rx']) * 0.002 - 30)
            get_onu_redaman_rx_result = get_onu_redaman_rx - 131.07 if get_onu_redaman_rx > 90 else get_onu_redaman_rx
            get_onu_authpass = SNMP_GET(
                IP_OLT, 'intbnet', DICT_OID['ONU']['AUTHPASS'])
            get_onu_offline = SNMP_GET(
                IP_OLT, 'intbnet', DICT_OID['ONU']['OFFLINE'])
            get_onu_type = SNMP_GET(IP_OLT, 'intbnet', DICT_OID['ONU']['TYPE'])
            get_onu_name = SNMP_GET(IP_OLT, 'intbnet', DICT_OID['ONU']['NAME'])
            get_onu_sn = SNMP_GET(IP_OLT, 'intbnet', DICT_OID['ONU']['SN'])

            # Validaasi Status Modem
            if get_onu_state == 0:
                get_onu_state = "Logging"
            elif get_onu_state == 1:
                get_onu_state = "Los"
            elif get_onu_state == 2:
                get_onu_state = "SynMiB"
            elif get_onu_state == 3:
                get_onu_state = "Working"
            elif get_onu_state == 4:
                get_onu_state = "DyingGasp"
            elif get_onu_state == 5:
                get_onu_state = "AuthFailed"
            elif get_onu_state == 6:
                get_onu_state = "Offline"

            # Hasil Pengecekan
            RESULT_CHECKER = {
                'onu': {
                    'state': str(get_onu_state),
                    'redaman': {
                        'rx': float(round(get_onu_redaman_rx_result, 2))
                    },
                    'authpass': str(get_onu_authpass.decode('utf-8')),
                    'offline': str(get_onu_offline.decode('utf-8')),
                    'type': str(get_onu_type.decode('utf-8')),
                    'name': str(get_onu_name.decode('utf-8')),
                    'serial_number': 'ZTEG' + str(get_onu_sn.hex()[8:]).upper()
                }
            }
            insertMonitoringBhome(ID_Customer=ID_CUSTOMER, State=RESULT_CHECKER['onu']['state'], Redaman=RESULT_CHECKER['onu']['redaman']['rx'],Offline=RESULT_CHECKER['onu']['offline'],Created_at=timestamp)
        except:
            pass
