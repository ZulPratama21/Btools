import pymysql
from database.connection import create_conntection

def insertMonitoringAllModem(IP_Olt, ID_Noc, Name, Type, Serial_Number, State, Redaman_Rx, Authpass, Offline):
    try:
        conn = create_conntection()
        cursor = conn.cursor()
        cursor.execute(f"""INSERT INTO monitoring_all_modem (IP_Olt, ID_Noc, Name, Type, Serial_Number, State, Redaman_Rx, Authpass, Offline, Created_At) 
                       VALUES ('{IP_Olt}', '{ID_Noc}', '{Name}', '{Type}', '{Serial_Number}', '{State}', '{Redaman_Rx}', '{Authpass}', '{Offline}', NOW());""")
        conn.commit()
        print("Data inserted successfully!")

    except Exception as err:
        print("Error inserting data:", err)

    return None