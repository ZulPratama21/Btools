from puresnmp import get as SNMP_GET
from checking_all_modem import constants as CONSTANTS
from checking_all_modem.query import *
import time, datetime

def tambahkan_nol_di_depan(angka):
    # Mengonversi angka ke string
    angka_str = str(angka)

    # Jika panjang string kurang dari 2, tambahkan "0" di depannya
    if len(angka_str) < 2:
        angka_str = "0" + angka_str

    return angka_str

def run():
    olt_ip = CONSTANTS.OLT_IP_ADDRESS 
    for IP_OLT in range(len(olt_ip)):
        for NUMBER_PORT in range(1, 33):
            for NUMBER_PORT_ONU in range(1, 65):
                ID_NOC = str(IP_OLT+1) + str(tambahkan_nol_di_depan(NUMBER_PORT)) + str(tambahkan_nol_di_depan(NUMBER_PORT_ONU))
                
                DICT_OID = {
                    'ONU': {
                        'STATE': str(CONSTANTS.CONSTANT_OIDS['ONU']['STATE']) + str(CONSTANTS.CONSTANT_OID_PORT_ALL['port'][str(NUMBER_PORT)]['OID']) + '.' + str(NUMBER_PORT_ONU),
                        'REDAMAN': {
                            'rx': str(CONSTANTS.CONSTANT_OIDS['ONU']['REDAMAN']['rx']) + str(CONSTANTS.CONSTANT_OID_PORT_ALL['port'][str(NUMBER_PORT)]['OID']) + '.' + str(NUMBER_PORT_ONU) + '.1'
                        },
                        'AUTHPASS': str(CONSTANTS.CONSTANT_OIDS['ONU']['AUTHPASS']) + str(CONSTANTS.CONSTANT_OID_PORT_ALL['port'][str(NUMBER_PORT)]['OID']) + '.' + str(NUMBER_PORT_ONU),
                        'OFFLINE': str(CONSTANTS.CONSTANT_OIDS['ONU']['OFFLINE']) + str(CONSTANTS.CONSTANT_OID_PORT_ALL['port'][str(NUMBER_PORT)]['OID']) + '.' + str(NUMBER_PORT_ONU),
                        'TYPE': str(CONSTANTS.CONSTANT_OIDS['ONU']['TYPE']) + str(CONSTANTS.CONSTANT_OID_PORT_ALL['port'][str(NUMBER_PORT)]['OID']) + '.' + str(NUMBER_PORT_ONU),
                        'NAME': str(CONSTANTS.CONSTANT_OIDS['ONU']['NAME']) + str(CONSTANTS.CONSTANT_OID_PORT_ALL['port'][str(NUMBER_PORT)]['OID']) + '.' + str(NUMBER_PORT_ONU),
                        'SN': str(CONSTANTS.CONSTANT_OIDS['ONU']['SN']) + str(CONSTANTS.CONSTANT_OID_PORT_ALL['port'][str(NUMBER_PORT)]['OID']) + '.' + str(NUMBER_PORT_ONU),
                    }
                }

                try:
                    get_onu_state = SNMP_GET(olt_ip[IP_OLT], 'intbnet', DICT_OID['ONU']['STATE'])
                    get_onu_redaman_rx = (SNMP_GET(olt_ip[IP_OLT], 'intbnet', DICT_OID['ONU']['REDAMAN']['rx']) * 0.002 - 30)
                    get_onu_redaman_rx_result = get_onu_redaman_rx - 131.07 if get_onu_redaman_rx > 90 else get_onu_redaman_rx
                    get_onu_authpass = SNMP_GET(olt_ip[IP_OLT], 'intbnet', DICT_OID['ONU']['AUTHPASS'])
                    get_onu_offline = SNMP_GET(olt_ip[IP_OLT], 'intbnet', DICT_OID['ONU']['OFFLINE'])
                    get_onu_type = SNMP_GET(olt_ip[IP_OLT], 'intbnet', DICT_OID['ONU']['TYPE'])
                    get_onu_name = SNMP_GET(olt_ip[IP_OLT], 'intbnet', DICT_OID['ONU']['NAME'])
                    get_onu_sn = SNMP_GET(olt_ip[IP_OLT], 'intbnet', DICT_OID['ONU']['SN'])
                except:
                    continue

                if get_onu_state == 0:
                    get_onu_state = "Logging"
                elif get_onu_state == 1:
                    get_onu_state = "Los"
                elif get_onu_state == 2:
                    get_onu_state = "SynMiB"
                elif get_onu_state == 3:
                    get_onu_state = "Working"
                elif get_onu_state == 4:
                    get_onu_state = "DyingGasp"
                elif get_onu_state == 5:
                    get_onu_state = "AuthFailed"
                elif get_onu_state == 6:
                    get_onu_state = "Offline"

                if str(get_onu_type.decode('utf-8')) == "FD514GD-R460":
                    serial_number_patern = "DF18"
                else:
                    serial_number_patern = "ZTEG"

                insertMonitoringAllModem(olt_ip[IP_OLT], ID_NOC, str(get_onu_name.decode('utf-8')), str(get_onu_type.decode('utf-8')), serial_number_patern + str(get_onu_sn.hex()[8:]).upper(), get_onu_state, str(round(get_onu_redaman_rx_result, 2)), str(get_onu_authpass.decode('utf-8')), str(get_onu_offline.decode('utf-8')))
