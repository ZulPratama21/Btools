import pymysql

MYSQL_DATABASE_HOST = '172.16.1.75'
MYSQL_DATABASE_USER = 'btools'
MYSQL_DATABASE_PASSWORD = 'rbxWfM5YXCbNRspJ'
MYSQL_DATABASE_DB = 'btools'

def create_conntection():
    connection = None
    try:
        connection = pymysql.connect(
            host=MYSQL_DATABASE_HOST,
            user=MYSQL_DATABASE_USER,
            password=MYSQL_DATABASE_PASSWORD,
            database=MYSQL_DATABASE_DB
        )
    except Exception as e:
        print(e)
    return connection