import datetime, os, sys
from zipfile import ZipFile
from periodic_checking.link_backup import run as LINKBACKUP_RUN
from periodic_checking.link_main import run as LINKMAIN_RUN
from periodic_checking.link_peering import run as LINKPEERING_RUN
from periodic_checking.link_sfp import run as LINKSFP_RUN
from periodic_checking.link_transit import run as LINKTRANSIT_RUN
from periodic_checking.telegram.telegram import Send as SEND

from checking_redaman.bhome import run as CHECK_REDAMAN_BHOME_RUN

from spreadsheet.data_odp import run as SPREADSHEET_ODP

from checking_suspend.main import run as CHECK_SUSPEND_RUN

from checking_all_modem.app import run as CHECK_ALL_MODEM_RUN

def compressFile(nameFile):
    # Membuat Zip File
    with ZipFile(f'{nameFile}', 'w') as zipObj2:
        zipObj2.write(os.path.join(os.path.dirname(__file__)) + '/periodic_checking/files/link_backup.csv')
        zipObj2.write(os.path.join(os.path.dirname(__file__)) + '/periodic_checking/files/link_peering.csv')
        zipObj2.write(os.path.join(os.path.dirname(__file__)) + '/periodic_checking/files/link_transit.csv')
        zipObj2.write(os.path.join(os.path.dirname(__file__)) + '/periodic_checking/files/link_main.csv')
        zipObj2.write(os.path.join(os.path.dirname(__file__)) + '/periodic_checking/files/link_sfp.csv')

    # Hapus File
    os.remove(os.path.join(os.path.dirname(__file__)) + '/periodic_checking/files/link_backup.csv')
    os.remove(os.path.join(os.path.dirname(__file__)) + '/periodic_checking/files/link_peering.csv')
    os.remove(os.path.join(os.path.dirname(__file__)) + '/periodic_checking/files/link_transit.csv')
    os.remove(os.path.join(os.path.dirname(__file__)) + '/periodic_checking/files/link_main.csv')
    os.remove(os.path.join(os.path.dirname(__file__)) + '/periodic_checking/files/link_sfp.csv')

    # Kirim File Zip Ke Telegram
    SEND.files(nameFiles=nameFile)
    os.remove(nameFile)

def execution(execution):
    if execution == 'periodic_checking':
        SEND.start()
        LINKBACKUP_RUN()
        LINKMAIN_RUN()
        LINKPEERING_RUN()
        LINKSFP_RUN()
        LINKTRANSIT_RUN()
        SEND.link_main()
        SEND.link_backup()
        compressFile(f"Pengecekan_Berkala-{datetime.datetime.now().strftime('%d-%B-%Y_%H')}.zip")
    elif execution == 'checking_redaman_bhome':
        CHECK_REDAMAN_BHOME_RUN()
    elif execution == 'spreadsheet_odp':
        SPREADSHEET_ODP()
    elif execution == 'checking_suspend':
        CHECK_SUSPEND_RUN()
    elif execution == 'checking_all_modem':
        CHECK_ALL_MODEM_RUN()

if __name__ == '__main__':
    execution(sys.argv[1])
    
