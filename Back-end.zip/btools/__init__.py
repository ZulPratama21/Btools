from flask import Flask, redirect, url_for, make_response, jsonify, render_template, session, flash
from flask_limiter import Limiter, RequestLimit
from flask_limiter.util import get_remote_address
from flaskext.mysql import MySQL
from flask_bcrypt import Bcrypt
from flask_session import Session
from flask_login import LoginManager, login_required, current_user, login_user, UserMixin, logout_user
from functools import wraps
from flask_mail import Mail, Message
import secrets, pymysql
import openpyxl
from io import BytesIO
import datetime

app = Flask(__name__)

@app.errorhandler(429)
def ratelimit_handler(e):
    return render_template('default_limiter.html', e=e)

limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["999999 per day", "999999 per hour"],
    storage_uri="memory://"
)
app.config.from_object('config')
mysql = MySQL(app)
mysql.init_app(app)
Session(app)
bcrypt = Bcrypt(app)

# Konfigurasi Login Manager
login_manager = LoginManager(app)
login_manager.login_view = 'public.users.index_login'

# Konfigurasi Flask-Mail
app.config['MAIL_SERVER'] = 'smtp.bnet.id'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'info@bnet.id'  # Ganti dengan email Anda
app.config['MAIL_PASSWORD'] = 'MH3_PeEg5ds'  # Ganti dengan password email Anda
app.config['MAIL_DEFAULT_SENDER'] = 'info@bnet.id'  # Ganti dengan email Anda

mail = Mail(app)

# Model User
class User(UserMixin):
    def __init__(self, user_id, username, password, level):
        self.id = user_id
        self.username = username
        self.password = password
        self.level = level

    def get_id(self):
        return str(self.id)

    def is_authenticated(self):
        return True

    def is_active(self):
        return True

    def is_anonymous(self):
        return False
    
@login_manager.user_loader
def load_user(user_id):
    cursor = mysql.connect().cursor()
    cursor.execute(
        f"SELECT User_id, Username, Password, Level FROM Users WHERE User_id='{user_id}'")
    user_data = cursor.fetchone()
    cursor.close()
    if user_data:
        user_id, username, password, level = user_data
        return User(user_id, username, password, level)
    
    return None

def role_required(allowed_roles):
    def decorator(func):
        @wraps(func)
        @login_required
        def wrapper(*args, **kwargs):
            if current_user.is_authenticated and current_user.level in allowed_roles:
                return func(*args, **kwargs)
            else:
                return 'Access Denied', 403
        return wrapper
    return decorator

def generate_activation_link(email):
    # Generate token untuk link aktivasi
    token = secrets.token_urlsafe(32)
    return token

def send_activation_email(atasan, name, email, activation_link):
    # Kirim email aktivasi dengan menggunakan Flask-Mail
    subject = 'Aktivasi Akun - B-Tools'
    body = f""" 
Kepada Yang Terhormat,

Kami ingin memberitahukan bahwa seorang karyawan baru telah mendaftar akun di Aplikasi Web B-Tools. Berikut adalah detail akunnya:

Nama: {name}
Email: {email}

Karyawan ini memerlukan bantuan Anda untuk mengaktivasi akunnya. Mohon untuk mengklik link berikut ini untuk mengaktifkan akun:

Link Aktivasi: {url_for('activate_account', token=activation_link, _external=True)}

Terima kasih atas perhatian dan bantuannya.

Hormat kami,
Tim NOC
"""
    message = Message(subject=subject, recipients=[atasan], body=body)
    mail.send(message)

def send_success_activation_email(email, fullname):
    # Kirim email aktivasi dengan menggunakan Flask-Mail
    subject = 'Aktivasi Akun - B-Tools'
    body = f""" 
Kepada {fullname},

Kami ingin memberitahukan bahwa akun Anda telah berhasil diaktivasi. Anda sekarang dapat login dan mulai menggunakan Aplikasi Web B-Tools.

Terima kasih atas perhatiannya.

Hormat kami,
Tim NOC
"""
    message = Message(subject=subject, recipients=[email], body=body)
    mail.send(message)

@app.route('/activate/<token>')
@role_required(['Master'])
def activate_account(token):
    fullname = session.get('fullname')
    try:
        with mysql.connect() as connection, connection.cursor(pymysql.cursors.DictCursor) as cursor:
            # Proses aktivasi akun berdasarkan token di sini
            cursor.execute(f"SELECT * FROM Users WHERE Token='{token}'")
            account = cursor.fetchone()
            
            fullname_new = account['Name']
            email_new = account['Email']

            if account:
                approved = account['Approved']

                if approved == '0':
                    # Jika Approved_1 sudah diisi dan Approved_2 belum diisi, maka isi Approved_2 dengan nilai fullname dan aktifkan akun
                    cursor.execute(f"UPDATE Users SET Approved='{fullname}', Active=1 WHERE Token='{token}'")
                    connection.commit()
                    send_success_activation_email(email_new, fullname_new)
                    flash(f"Akun berhasil diaktivasi, silahkan hubungi {fullname_new} untuk cek email yang dikirim oleh sistem")
                    return redirect(url_for('index_profile'))
                else:
                    # Jika Approved_1 dan Approved_2 sudah diisi, berikan pesan sesuai kebutuhan
                    flash(f"Akun {fullname_new} sudah diaktivasi")
                    return redirect(url_for('index_profile'))
            else:
                flash(f"Token yang anda buka tidak valid")
                return redirect(url_for('index_profile'))
    except Exception as e:
        flash(f"Akun tidak ditemukan")
        return redirect(url_for('index_profile'))


@app.route('/')
def index():
    return redirect(url_for('index_profile'))
    
@app.route('/profile')
@role_required(['Master', 'NOC', 'Technical', 'Finance', 'CR'])
def index_profile():
    return render_template('users/profile.html')

@app.route('/api/v1/')
def index_api():
    return {
        "pages": {
            "installation": {
                "execute": {
                    "bhome_1": {
                        "description": "Generate Command OLT For Client Bhome Mode Bridge",
                        "example": "http://localhost/api/v1/installation/bhome/1/execute?serial_number=ZTECGEXXXX&id_noc=10101&ip_address=192.168.100.1&subnetmask=255.255.255.0&limitation=Gaming-10M",
                        "pattern": "http://localhost/api/v1/installation/bhome/1/execute?serial_number={}&id_noc={}&ip_address={}&subnetmask={}&limitation={[Gaming-10M, Gaming-20M, Gaming-50M, Gaming-75M]}"
                    },
                    "bhome_2": {
                        "description": "Generate Command OLT For Client Bhome Mode Embedded",
                        "example": "http://localhost/api/v1/installation/bhome/2/execute?serial_number=ZTECGEXXXX&id_noc=10101&limitation=Gaming-10M",
                        "pattern": "http://localhost/api/v1/installation/bhome/2/execute?serial_number={}&id_noc={}&limitation={[Gaming-10M, Gaming-20M, Gaming-50M, Gaming-75M]}"
                    }
                }
            },
            "easyexecute":{
                "description": "Execute Command For OLT",
                "example" : "http://localhost/api/v1/easyexecute/olt?command=show%20gpon%20onu%20state%20gpon-olt_1%2F1%2F1&id_olt=OLT1",
                "pattern" : "http://localhost/api/v1/easyexecute/olt?command={}&id_olt={[OLT1, OLT2, OLT3, OLT4]}"
            },
            "troubleshoot": {
                "bhome": {
                    "database": {
                        "clients": {
                            "description": "Get All Data Clients",
                            "example": "http://localhost/api/v1/troubleshoot/bhome/database/clients"
                        },
                        "filter": {
                            "description": "Filter Client By ID Customer",
                            "example": "http://localhost/api/v1/troubleshoot/bhome/database/clients?id_customer=CA0001803",
                            "pattern": "http://localhost/api/v1/troubleshoot/bhome/database/clients?id_customer={}"
                        }
                    },
                    "realtime": {
                        "mikrotik": {
                            "traffic": {
                                "description": "Get Traffic Internet Client From Queue",
                                "example": "http://localhost/api/v1/troubleshoot/bhome/mikrotik/realtime/traffic?id_customer=CA0001803",
                                "pattern": "http://localhost/api/v1/troubleshoot/bhome/mikrotik/realtime/traffic?id_customer={}"
                            },
                            "ping": {
                                "description": "Ping To Host Client From Parent",
                                "example": "http://localhost/api/v1/troubleshoot/bhome/mikrotik/realtime/ping?id_customer=CA0001803",
                                "pattern": "http://localhost/api/v1/troubleshoot/bhome/mikrotik/realtime/ping?id_customer={}"
                            }
                        },
                        "olt": {
                            "info": {
                                "description": "Get Modem Info From OLT",
                                "example": "http://localhost/api/v1/troubleshoot/bhome/olt/realtime/info?id_customer=CA0001803",
                                "pattern": "http://localhost/api/v1/troubleshoot/bhome/olt/realtime/info?id_customer={}"
                            }
                        }
                    }
                }
            },
            "monitoring": {
                "wireless_discovery": {
                    "database": {
                        "wireless": {
                            "description": "Get All Data Wireless",
                            "example": "http://localhost/api/v1/monitoring/wireless_discovery/database/wireless"
                        },
                        "filter": [
                            {
                                "description": "Get All Data Restricted Frequency Wireless",
                                "by": "Restricted Frequency",
                                "example": "http://localhost/api/v1/monitoring/wireless_discovery/database/wireless?restricted_frequency=yes"
                            },
                            {
                                "description": "Get All Data Recomendation Tunning Wireless",
                                "by": "Tunning Recomendation",
                                "example": "http://localhost/api/v1/monitoring/wireless_discovery/database/wireless?tunning_recomendation=yes"
                            }
                        ]
                    }
                }
            }
        }
    }

#/Api
from btools.apps.views import mod_api as parrentApps
from btools.apps.installation.installationAPI import mod as childAppsInstallation
from btools.apps.monitoring.monitoringAPI import mod as childAppsMonitoring
from btools.apps.easyExecute.easyExecuteAPI import mod as childAppsEasyExecute
from btools.apps.troubleshoot.troubleshootAPI import mod as childAppsTroubleshootBhome
from btools.apps.users.usersAPI import mod as childAppsUsers
from btools.apps.periodic_checking.periodicAPI import mod as childAppsPeriodic
from btools.apps.spreadsheet.spreadsheetAPI import mod as childAppsSpreadsheet
from btools.apps.accounting.accountingAPI import mod as childAppsAccounting

parrentApps.register_blueprint(childAppsInstallation)
parrentApps.register_blueprint(childAppsMonitoring)
parrentApps.register_blueprint(childAppsEasyExecute)
parrentApps.register_blueprint(childAppsTroubleshootBhome)
parrentApps.register_blueprint(childAppsUsers)
parrentApps.register_blueprint(childAppsPeriodic)
parrentApps.register_blueprint(childAppsSpreadsheet)
parrentApps.register_blueprint(childAppsAccounting)
app.register_blueprint(parrentApps)

#/Public
from btools.apps.views import mod_public as parrentAppsPublic
from btools.apps.installation.installationViews import mod as childAppsInstallationViews
from btools.apps.monitoring.monitoringViews import mod as childAppsMonitoringViews
from btools.apps.easyExecute.easyExecuteViews import mod as childAppsEasyExecuteViews
from btools.apps.troubleshoot.troubleshootViews import mod as childAppsTroubleshootBhomeViews
from btools.apps.users.usersViews import mod as childAppsUsersViews
from btools.apps.periodic_checking.periodicViews import mod as childAppsperiodicViews
from btools.apps.spreadsheet.spreadsheetViews import mod as childAppsSpreadsheetViews
from btools.apps.accounting.accountingViews import mod as childAppsAccountingViews

parrentAppsPublic.register_blueprint(childAppsInstallationViews)
parrentAppsPublic.register_blueprint(childAppsMonitoringViews)
parrentAppsPublic.register_blueprint(childAppsEasyExecuteViews)
parrentAppsPublic.register_blueprint(childAppsTroubleshootBhomeViews)
parrentAppsPublic.register_blueprint(childAppsUsersViews)
parrentAppsPublic.register_blueprint(childAppsperiodicViews)
parrentAppsPublic.register_blueprint(childAppsSpreadsheetViews)
parrentAppsPublic.register_blueprint(childAppsAccountingViews)
app.register_blueprint(parrentAppsPublic)

#/Private
from btools.apps.views import mod_private as parrentAppsPrivate
from btools.apps.dashboard.dashboardViews import mod as childAppsDashboardsViews

parrentAppsPrivate.register_blueprint(childAppsDashboardsViews)
app.register_blueprint(parrentAppsPrivate)

