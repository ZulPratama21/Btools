from btools import app
app.run(debug=False, host='0.0.0.0', threaded=True, port=80)